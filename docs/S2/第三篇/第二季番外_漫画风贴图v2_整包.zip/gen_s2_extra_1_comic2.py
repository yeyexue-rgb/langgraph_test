#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""番外篇 · 漫画风贴图 v2（漫说测试）：
   字号加大 · 气泡重做 · 内容铺满版面
   - 10 张竖版贴图（1080x1920，sticker-s2xc-01..10）
   - 1 张横版封面（1880x800，cover-s2xc-01）
字体：ZCOOL KuaiLe（站酷快乐体） 渲染：rsvg-convert
"""
import os, subprocess

OUT = os.path.expanduser("~/.openclaw/workspace/session-files/01M20S67DZSWEWWHNP370TWZVB/agent-testing-series/figs")
os.makedirs(OUT, exist_ok=True)

W, H = 1080, 1920
MX, CW = 60, 960
INK = "#1F1B16"
PAPER = "#FFF6E5"
WHT = "#FFFFFF"
YEL = "#FFD93D"
RED = "#FF6B6B"
BLU = "#4D8BFF"
GRN = "#3FBF63"
PUR = "#9B5DFF"
SKIN = "#FFE0B2"
FONT = "ZCOOL KuaiLe, Noto Sans CJK SC"

# 字号基线（v2 全面加大）
F_H1 = 96      # 主标题
F_H2 = 64      # 副标题
F_CHAP = 44    # 话数标签
F_BUB = 46     # 气泡正文
F_CT = 48      # 卡片标题
F_CB = 38      # 卡片正文
F_CS = 32      # 卡片小字
F_LEAD = 60    # 金句


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def T(x, y, s, size, fill=INK, anchor="start", rot=None, sw=0, swc=INK, sp=0):
    tr = f' transform="rotate({rot} {x} {y})"' if rot else ''
    st = f' stroke="{swc}" stroke-width="{sw}" paint-order="stroke"' if sw else ''
    ls = f' letter-spacing="{sp}"' if sp else ''
    return (f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" text-anchor="{anchor}"'
            f' font-family="{FONT}"{tr}{st}{ls}>{esc(s)}</text>')


def panel(x, y, w, h, fill=WHT, sw=7, rot=None, dash=None):
    tr = f' transform="rotate({rot} {x+w/2} {y+h/2})"' if rot else ''
    d = f' stroke-dasharray="{dash}"' if dash else ''
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="30" fill="{fill}"'
            f' stroke="{INK}" stroke-width="{sw}"{d}{tr}/>')


def card(y, h, fill=WHT, x=MX, w=CW, sw=7):
    return panel(x, y, w, h, fill, sw)


def bubble(x, y, w, h, lines, size=F_BUB, tail="bl", fill=WHT, lh=None):
    """对话气泡 v2：单条干净尾巴 + 更宽内边距"""
    lh = lh or int(size * 1.46)
    s = panel(x, y, w, h, fill, 7)
    pad = 46
    if tail == "bl":
        bx0, bx1 = x + 52, x + 168
        s += (f'<path d="M {bx0} {y+h-10} L {bx0+10} {y+h+66} L {bx1} {y+h-10} Z" fill="{fill}"'
              f' stroke="{INK}" stroke-width="7" stroke-linejoin="round"/>'
              f'<rect x="{bx0+8}" y="{y+h-16}" width="{bx1-bx0-16}" height="12" fill="{fill}"/>')
    elif tail == "br":
        bx0, bx1 = x + w - 168, x + w - 52
        s += (f'<path d="M {bx0} {y+h-10} L {bx1-10} {y+h+66} L {bx1} {y+h-10} Z" fill="{fill}"'
              f' stroke="{INK}" stroke-width="7" stroke-linejoin="round"/>'
              f'<rect x="{bx0+8}" y="{y+h-16}" width="{bx1-bx0-16}" height="12" fill="{fill}"/>')
    elif tail == "tr":
        bx0, bx1 = x + w - 190, x + w - 60
        s += (f'<path d="M {bx0} {y+10} L {bx1-6} {y-64} L {bx1} {y+10} Z" fill="{fill}"'
              f' stroke="{INK}" stroke-width="7" stroke-linejoin="round"/>'
              f'<rect x="{bx0+8}" y="{y+4}" width="{bx1-bx0-16}" height="12" fill="{fill}"/>')
    cy = y + pad + int(size * 0.82)
    for ln in lines:
        s += T(x + pad, cy, ln, size)
        cy += lh
    return s


def cloud(x, y, w, h, lines, size=38, lh=54):
    s = (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{h//2}" fill="{WHT}"'
         f' stroke="{INK}" stroke-width="6" stroke-dasharray="16 11"/>')
    s += f'<circle cx="{x+46}" cy="{y+h+34}" r="16" fill="{WHT}" stroke="{INK}" stroke-width="6"/>'
    s += f'<circle cx="{x+18}" cy="{y+h+72}" r="10" fill="{WHT}" stroke="{INK}" stroke-width="6"/>'
    cy = y + 62
    for ln in lines:
        s += T(x + 44, cy, ln, size)
        cy += lh
    return s


def sfx(x, y, text, size=64, rot=-14, col=RED, sw=4):
    return T(x, y, text, size, col, rot=rot, sw=sw, swc=INK)


def badge(x, y, text, fill=YEL, size=36, pad=40, h=68, anchor="start"):
    w = int(len(text) * size * 0.96 + pad * 2)
    if anchor == "middle":
        x = x - w // 2
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{h//2}" fill="{fill}" stroke="{INK}" stroke-width="6"/>'
            + T(x + w // 2, y + h // 2 + size // 3, text, size, INK, anchor="middle"))


def mascot(cx, cy, s=1.0, mood="happy", clothes=BLU):
    """小测试员（v2：线条加粗）"""
    g = [f'<g transform="translate({cx} {cy}) scale({s})">']
    g.append(f'<rect x="-46" y="150" width="32" height="88" rx="15" fill="#3B4A6B" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<rect x="14" y="150" width="32" height="88" rx="15" fill="#3B4A6B" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<rect x="-70" y="52" width="140" height="112" rx="34" fill="{clothes}" stroke="{INK}" stroke-width="7"/>')
    al = '-120,116 -86,84' if mood in ("yeah", "happy") else '-126,96 -84,120'
    g.append(f'<polyline points="{al}" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>')
    g.append(f'<polyline points="86,84 120,116" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>')
    g.append(f'<circle cx="-128" cy="{80 if mood in ("yeah","happy") else 92}" r="21" fill="{SKIN}" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<circle cx="128" cy="92" r="21" fill="{SKIN}" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<circle cx="0" cy="-6" r="80" fill="{SKIN}" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<path d="M -80 -22 A 80 80 0 0 1 80 -22 Q 42 -76 0 -68 Q -42 -76 -80 -22 Z" fill="{INK}"/>')
    if mood == "cool":
        g.append(f'<rect x="-60" y="-32" width="48" height="28" rx="9" fill="{INK}"/>')
        g.append(f'<rect x="12" y="-32" width="48" height="28" rx="9" fill="{INK}"/>')
        g.append(f'<path d="M -60 -32 L -12 -32 M 12 -32 L 60 -32" stroke="{INK}" stroke-width="7"/>')
    elif mood == "shock":
        g.append(f'<circle cx="-27" cy="-14" r="14" fill="{WHT}" stroke="{INK}" stroke-width="6"/>')
        g.append(f'<circle cx="27" cy="-14" r="14" fill="{WHT}" stroke="{INK}" stroke-width="6"/>')
        g.append(f'<circle cx="-27" cy="-14" r="6" fill="{INK}"/>')
        g.append(f'<circle cx="27" cy="-14" r="6" fill="{INK}"/>')
    else:
        g.append(f'<circle cx="-27" cy="-14" r="10" fill="{INK}"/>')
        g.append(f'<circle cx="27" cy="-14" r="10" fill="{INK}"/>')
        g.append(f'<circle cx="-24" cy="-17" r="3.4" fill="{WHT}"/>')
        g.append(f'<circle cx="30" cy="-17" r="3.4" fill="{WHT}"/>')
    g.append(f'<ellipse cx="-52" cy="16" rx="16" ry="10" fill="{RED}" opacity="0.5"/>')
    g.append(f'<ellipse cx="52" cy="16" rx="16" ry="10" fill="{RED}" opacity="0.5"/>')
    if mood == "shock":
        g.append(f'<ellipse cx="0" cy="38" rx="18" ry="22" fill="{INK}"/>')
    elif mood == "sweat":
        g.append(f'<path d="M -26 40 q 13 13 26 0 q 13 -13 26 0" fill="none" stroke="{INK}" stroke-width="7"/>')
    elif mood == "think":
        g.append(f'<path d="M -22 40 q 22 9 44 -2" fill="none" stroke="{INK}" stroke-width="7"/>')
    elif mood == "cool":
        g.append(f'<path d="M -28 36 q 28 17 56 -7" fill="none" stroke="{INK}" stroke-width="7"/>')
    else:
        g.append(f'<path d="M -30 32 q 30 36 60 0" fill="none" stroke="{INK}" stroke-width="8"/>')
    if mood == "sweat":
        g.append(f'<path d="M 70 -50 q 15 24 0 32 q -15 -8 0 -32 Z" fill="{BLU}" stroke="{INK}" stroke-width="5"/>')
    g.append('</g>')
    return "".join(g)


def head(n):
    return (f'<rect x="0" y="0" width="{W}" height="100" fill="{YEL}"/>'
            f'<line x1="0" y1="100" x2="{W}" y2="100" stroke="{INK}" stroke-width="7"/>'
            + T(36, 68, "漫说测试 · 番外篇", 36)
            + T(W - 36, 68, f"{n}/10", 38, anchor="end"))


def wmc():
    return (f'<rect x="{(W-400)//2}" y="1830" width="400" height="62" rx="31" fill="{WHT}" stroke="{INK}" stroke-width="6"/>'
            + T(W // 2, 1874, "Python测试之道", 34, anchor="middle"))


def build(elems, w=W, h=H):
    defs = (f'<defs><pattern id="dots" width="28" height="28" patternUnits="userSpaceOnUse">'
            f'<circle cx="5" cy="5" r="2.6" fill="{INK}" opacity="0.09"/></pattern></defs>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'font-family="{FONT}">' + defs + f'<rect width="{w}" height="{h}" fill="{PAPER}"/>'
            f'<rect width="{w}" height="{h}" fill="url(#dots)"/>' + "".join(elems) + "</svg>")


def save(name, svg, w=W, h=H):
    ps = os.path.join(OUT, f"{name}-src.svg")
    pp = os.path.join(OUT, f"{name}.png")
    open(ps, "w", encoding="utf-8").write(svg)
    subprocess.run(["rsvg-convert", ps, "-o", pp], check=True)
    print("saved", pp)


def kv(y, items, h=None, fill=WHT, size=F_CB, lh=64, title=None, tcol=INK):
    """按行铺满的卡片：items=[(标签, 值)]；返回 (svg, 卡片高度)"""
    n = len(items)
    hh = h or (150 + lh * n if title else 120 + lh * n)
    s = card(y, hh, fill)
    cy = y + 78
    if title:
        s += T(MX + 44, cy, title, F_CT, tcol)
        cy += 76
    for a, b in items:
        s += f'<circle cx="{MX+62}" cy="{cy-14}" r="15" fill="{GRN}" stroke="{INK}" stroke-width="5"/>'
        s += T(MX + 100, cy, a, size)
        if b:
            s += T(MX + CW - 44, cy, b, int(size * 0.72), "#6B6257", anchor="end")
        cy += lh
    return s, hh


# ============================================================ 10 张漫画贴图
P = []

# ---- 1 封面 ----
e = [head(1)]
e.append(badge(W // 2, 150, "漫说测试", YEL, 46, anchor="middle"))
e.append(T(W // 2, 330, "学 Agent 测试", F_H1, INK, anchor="middle"))
e.append(T(W // 2, 470, "其实是件很划算的事", 82, RED, anchor="middle", sw=4))
e.append(bubble(70, 530, 640, 210, ["划算？", "怎么看出来的？"], 46, "bl"))
e.append(mascot(810, 910, 1.22, "happy"))
e.append(card(1110, 340, WHT))
e.append(T(MX + 44, 1200, "入口是 Agent", F_CT))
e.append(T(MX + 44, 1290, "拿走的是一整套通用底座", F_CT, BLU))
e.append(T(MX + 44, 1380, "前沿是赠品 · 底座才是主菜", F_CS, "#6B6257"))
e.append(card(1490, 310, YEL))
e.append(T(MX + 44, 1590, "先学，学了不亏", 52))
e.append(T(MX + 44, 1680, "转不转，到时候你自己有答案", 40))
e.append(T(MX + 44, 1766, "全套 9 话 · 读完约 4 分钟", 30, "#6B5744"))
e.append(wmc())
P.append(build(e))

# ---- 2 第1话 ----
e = [head(2)]
e.append(T(MX, 190, "第 1 话 · 图什么？", F_CHAP, "#6B6257"))
e.append(mascot(200, 430, 0.8, "happy"))
e.append(bubble(400, 280, 620, 200, ["不是为了", "“不被淘汰”"], 46, "bl"))
e.append(bubble(400, 540, 620, 200, ["这种话听多了人也麻了", "我不想拿焦虑当理由"], 38, "bl", fill="#FFF3F3"))
e.append(card(790, 380, WHT))
e.append(T(MX + 44, 880, "图它划算：投入产出比高", F_CT))
for i, a in enumerate(["为了测好 Agent，被迫要补的东西",
                       "每一样都通用、都长期值钱",
                       "不是“额外学的”，是“本来就该会的”"]):
    yy = 962 + i * 76
    e.append(f'<circle cx="{MX+62}" cy="{yy-14}" r="15" fill="{GRN}" stroke="{INK}" stroke-width="5"/>')
    e.append(T(MX + 100, yy, a, 36))
e.append(card(1200, 300, "#EAF3FF"))
e.append(T(MX + 44, 1290, "Agent 测试是“入口”", F_CT, BLU))
e.append(T(MX + 100, 1380, "但从里面能拿走的", 38))
e.append(T(MX + 100, 1458, "远不止“怎么测 Agent”", 38, BLU))
e.append(card(1530, 260, "#FFF7DA"))
e.append(T(MX + 44, 1620, "一句话", 40, "#6B5744"))
e.append(T(MX + 44, 1704, "先把它当成“测开化”的入口", 38))
e.append(sfx(880, 1150, "叮", 66, -12, YEL))
e.append(wmc())
P.append(build(e))

# ---- 3 第2话 ----
e = [head(3)]
e.append(T(MX, 190, "第 2 话 · 我也犹豫过", F_CHAP, "#6B6257"))
e.append(cloud(70, 250, 940, 150, ["顾虑一：又是一套很快过时的工具？"], 38))
e.append(cloud(70, 470, 940, 150, ["顾虑二：这东西离我的日常太远？"], 38))
e.append(mascot(210, 830, 0.78, "think"))
e.append(bubble(420, 700, 600, 200, ["现在看：", "一个半对、一个全错"], 42, "bl"))
s, h = kv(980, [], fill="#FFF7DA", title="真正难的部分")
e.append(s)
e.append(T(MX + 44, 1160, "跟“大模型”关系没那么大", F_CB))
e.append(T(MX + 44, 1240, "跟测试工程师的基本功关系很大", F_CB, INK))
e.append(card(1340, 300, WHT))
e.append(T(MX + 44, 1430, "工具会变，方法不会", F_CT, GRN))
e.append(T(MX + 44, 1520, "它难在工程、标准、证据", F_CB))
e.append(T(MX + 44, 1600, "这三样，恰好最值得长期积累", F_CS, "#6B6257"))
e.append(wmc())
P.append(build(e))

# ---- 4 第3话 ----
e = [head(4)]
e.append(T(MX, 190, "第 3 话 · 被迫补工程能力", F_CHAP, "#6B6257"))
e.append(bubble(70, 250, 620, 190, ["想测好它", "就得会写代码"], 46, "bl"))
e.append(mascot(840, 440, 0.74, "sweat"))
e.append(card(560, 480, "#0F172A"))
e.append(T(MX + 44, 660, "def test_agent_eval():", 40, "#9BE7B0"))
e.append(T(MX + 44, 730, "    case = LLMTestCase(...)", 40, "#9BE7B0"))
e.append(T(MX + 44, 800, "    assert_test(case, metrics)", 40, "#9BE7B0"))
e.append(T(MX + 44, 900, "# pytest · CI 门禁 · 读源码 · 抓现场", 34, YEL))
e.append(T(MX + 44, 980, "# 没有一样是 Agent 专属", 34, "#C9D4E8"))
s, h = kv(1090, [], fill=WHT, title="说白了")
e.append(s)
e.append(T(MX + 44, 1270, "Agent 测试是最自然的", F_CB))
e.append(T(MX + 44, 1350, "“测开化”借口", 52, BLU))
e.append(card(1450, 250, "#EAF7EE"))
e.append(T(MX + 44, 1540, "想测好它 → 必须变强", 42))
e.append(T(MX + 44, 1620, "这一步，比证书值钱得多", F_CS, "#4F6B57"))
e.append(wmc())
P.append(build(e))

# ---- 5 第4话 ----
e = [head(5)]
e.append(T(MX, 190, "第 4 话 · 从执行者到定义者", F_CHAP, "#6B6257"))
e.append(panel(70, 250, 440, 560, "#F0F0F0"))
e.append(T(290, 340, "以前 · 执行者", 42, "#5A6472", anchor="middle"))
e.append(mascot(290, 520, 0.66, "think", clothes="#9AA3B2"))
e.append(T(290, 760, "照着验就行", 36, "#5A6472", anchor="middle"))
e.append(panel(570, 250, 440, 560, "#EAF3FF"))
e.append(T(790, 340, "现在 · 定义者", 42, BLU, anchor="middle"))
e.append(mascot(790, 520, 0.66, "cool", clothes=PUR))
e.append(T(790, 760, "“对”由我来定", 36, PUR, anchor="middle"))
e.append(sfx(540, 480, "→", 96, -6, RED))
e.append(card(870, 250, YEL))
e.append(T(MX + 44, 960, "工具会过时，标准不会", 50))
e.append(T(MX + 44, 1050, "三年后没人记得 promptfoo", F_CS, "#6B5744"))
e.append(card(1170, 190, WHT))
e.append(T(MX + 44, 1250, "你现在的价值是哪种？", 42))
e.append(T(MX + 44, 1320, "“我做得快” → 效率", 36, "#5A6472"))
e.append(T(MX + 44, 1320, "", 36))
e.append(card(1400, 240, "#FFF3F3"))
e.append(T(MX + 44, 1490, "“我说了算” → 标准", 44, RED))
e.append(T(MX + 44, 1570, "护城河，从来是后者", F_CS, "#6B6257"))
e.append(wmc())
P.append(build(e))

# ---- 6 第5话 ----
e = [head(6)]
e.append(T(MX, 190, "第 5 话 · 表达力被逼出来", F_CHAP, "#6B6257"))
e.append(mascot(210, 450, 0.78, "shock"))
e.append(bubble(420, 280, 600, 200, ["裁判给 0.6 分", "凭什么？"], 46, "bl"))
e.append(card(540, 220, WHT, x=620, w=390))
e.append(T(815, 640, "0.6", 88, RED, anchor="middle"))
e.append(T(815, 720, "裁判评分", 34, "#6B6257", anchor="middle"))
e.append(card(820, 280, "#FFF3F3"))
e.append(T(MX + 44, 910, "你没法用“我觉得”糊弄过去", 44))
e.append(T(MX + 44, 1000, "因为评测本身，就是在建立", F_CB))
e.append(T(MX + 44, 1076, "“可被检验的判断”", F_CB, RED))
e.append(card(1150, 300, "#EAF7EE"))
e.append(T(MX + 44, 1240, "越往上走，越是在做", 42))
e.append(T(MX + 44, 1330, "“让人相信你的判断”", 46, GRN))
e.append(T(MX + 44, 1410, "这件事，却被严重低估", F_CS, "#4F6B57"))
e.append(card(1500, 220, WHT))
e.append(T(MX + 44, 1620, "会写 → 会讲 → 会被信任", 40))
e.append(wmc())
P.append(build(e))

# ---- 7 第6话 ----
e = [head(7)]
e.append(T(MX, 190, "第 6 话 · 主菜是底座", F_CHAP, "#6B6257"))
e.append(mascot(190, 420, 0.72, "cool"))
e.append(bubble(360, 270, 660, 190, ["前沿是赠品", "底座才是主菜"], 46, "bl"))
e.append(card(540, 620, WHT))
e.append(T(MX + 44, 630, "主菜 · 高通用性", F_CT, RED))
rows7 = [("接口 / 端到端自动化", "任何后端系统"), ("pytest 工程化", "所有自动化项目"),
         ("CI 门禁与卡点", "研发流程任一环节"), ("读源码 + 调试定位", "让 bug 报告有含金量")]
for i, (a, b) in enumerate(rows7):
    y = 720 + i * 96
    e.append(f'<circle cx="{MX+62}" cy="{y-14}" r="15" fill="{GRN}" stroke="{INK}" stroke-width="5"/>')
    e.append(T(MX + 100, y, a, 38))
    e.append(T(MX + CW - 44, y, b, 28, "#6B6257", anchor="end"))
e.append(card(1200, 260, YEL))
e.append(T(MX + 44, 1290, "赠品 · 前沿标签", 42))
e.append(T(MX + 44, 1370, "LLM 评测方法论 · Agent 安全思维", 32, "#6B5744"))
e.append(T(MX + 44, 1420, "可观测留档 · 判据思维", 32, "#6B5744"))
e.append(card(1500, 220, "#EAF3FF"))
e.append(T(MX + 44, 1620, "主菜吃一辈子，赠品跟着换", 40, BLU))
e.append(wmc())
P.append(build(e))

# ---- 8 第7话 ----
e = [head(8)]
e.append(T(MX, 190, "第 7 话 · 哪些人不必勉强", F_CHAP, "#6B6257"))
items8 = [("不碰代码", "只想做业务测试 → 不必勉强", RED),
          ("想速成拿证", "门槛是能独立设计评测", PUR),
          ("没试验田", "先做出一个可演示结果", BLU)]
for i, (a, b, col) in enumerate(items8):
    y = 260 + i * 300
    e.append(card(y, 260, WHT))
    e.append(f'<circle cx="{MX+120}" cy="{y+130}" r="54" fill="{col}" stroke="{INK}" stroke-width="6"/>')
    e.append(T(MX + 120, y + 150, "×", 64, WHT, anchor="middle"))
    e.append(T(MX + 210, y + 110, a, 46))
    e.append(T(MX + 210, y + 186, b, 34, "#6B6257"))
e.append(card(1180, 330, "#EAF3FF"))
e.append(T(MX + 44, 1280, "顺便说句实话", 42, BLU))
e.append(T(MX + 44, 1370, "最硬的溢价还是工程能力", 44))
e.append(T(MX + 44, 1456, "不是“懂 AI”", 36, "#6B6257"))
e.append(mascot(200, 1620, 0.6, "happy"))
e.append(sfx(420, 1640, "先立住底座", 58, -8, GRN))
e.append(wmc())
P.append(build(e))

# ---- 9 第8话 ----
e = [head(9)]
e.append(T(MX, 190, "第 8 话 · 四步起步", F_CHAP, "#6B6257"))
steps = [("①", "用真项目", ["别造玩具", "就测你熟悉的"], BLU),
         ("②", "跑通一条", ["四样齐全：", "输入/期望/证据/判定"], GRN),
         ("③", "接进流程", ["每次改完", "都跑一遍"], YEL),
         ("④", "写篇复盘", ["以为懂的", "往往其实没懂"], PUR)]
for i, (num, h_, lines, col) in enumerate(steps):
    x = 60 + (i % 2) * 480
    y = 260 + (i // 2) * 430
    e.append(panel(x, y, 460, 390, WHT))
    e.append(f'<circle cx="{x+80}" cy="{y+80}" r="48" fill="{col}" stroke="{INK}" stroke-width="6"/>')
    e.append(T(x + 80, y + 98, num, 50, INK, anchor="middle"))
    e.append(T(x + 240, y + 98, h_, 46, INK, anchor="middle"))
    yy = y + 210
    for ln in lines:
        e.append(T(x + 40, yy, ln, 34, "#6B6257"))
        yy += 64
e.append(bubble(90, 1140, 900, 190, ["四步之后你手上会有", "一个能跑的用例 + 一次真实结果 + 一篇复盘"], 38, "tl", fill="#EAF7EE"))
e.append(card(1420, 300, "#FFF3F3"))
e.append(T(MX + 44, 1510, "别做的事（我踩过）", 42, RED))
e.append(T(MX + 44, 1596, "× 先买一堆课，然后一节没看完", 34))
e.append(T(MX + 44, 1664, "× 造一个“完美”玩具，两周后放弃", 34))
e.append(wmc())
P.append(build(e))

# ---- 10 第9话 ----
e = [head(10)]
e.append(T(MX, 190, "第 9 话 · 写在最后", F_CHAP, "#6B6257"))
e.append(T(W // 2, 350, "图它“顺便”", 90, RED, anchor="middle"))
e.append(card(430, 450, WHT))
for i, (a, b) in enumerate([("顺便", "把工程能力补齐了"),
                            ("顺便", "把定义标准的能力练出来了"),
                            ("顺便", "把表达和文档写顺了"),
                            ("顺便", "把前沿摸了一遍")]):
    y = 530 + i * 94
    e.append(T(MX + 44, y, a, 38, YEL))
    e.append(T(MX + 200, y, b, 42))
e.append(card(920, 260, "#FFF3C4"))
e.append(T(MX + 44, 1010, "不是因为它吓人", 42))
e.append(T(MX + 44, 1112, "而是因为它划算", 54, RED))
e.append(mascot(250, 1480, 0.68, "yeah"))
e.append(bubble(470, 1300, 570, 210, ["先学，学了不亏", "转不转，到时候再说"], 40, "bl"))
e.append(sfx(110, 1400, "嘿", 56, 12, GRN))
e.append(card(1660, 150, "#EAF3FF"))
e.append(T(MX + 44, 1752, "源码免费领：后台回复「agent」", 40, BLU))
e.append(wmc())
P.append(build(e))

for i, svg in enumerate(P, 1):
    save(f"sticker-s2xc-{i:02d}", svg)

# ============================================================ 漫画风横版封面
CW2, CH2 = 1880, 800
e = [f'<rect width="{CW2}" height="{CH2}" fill="{PAPER}"/>',
     f'<rect width="{CW2}" height="{CH2}" fill="url(#dots)"/>']
e.append(f'<rect x="0" y="0" width="{CW2}" height="16" fill="{YEL}"/>')
e.append(badge(90, 60, "漫说测试 · 番外篇", YEL, 40))
e.append(T(90, 310, "学 Agent 测试", 100, INK))
e.append(T(90, 430, "其实是件很划算的事", 84, RED, sw=4))
e.append(T(90, 520, "不劝转型 · 只算一笔账：入口是前沿，拿走的是底座", 40, "#6B6257"))
e.append(mascot(1520, 360, 1.06, "happy"))
e.append(bubble(1120, 560, 660, 170, ["何乐而不为？"], 52, "none"))
e.append(T(90, 660, "公众号：Python测试之道    ·    源码领取：后台回复「agent」", 38, INK))
e.append(sfx(1355, 300, "叮", 62, -12, GRN))
save("cover-s2xc-01", build(e, CW2, CH2), CW2, CH2)

print("all done")
