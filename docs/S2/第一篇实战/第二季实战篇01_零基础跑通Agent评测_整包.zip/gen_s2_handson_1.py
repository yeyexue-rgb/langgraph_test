#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第二季实战篇 01 图形：
   - 10 张竖版贴图（1080x1920，sticker-s2h-01..10）
   - 3 张文章配图（1600x1000，fig-s2h-a/b/c）
   - 1 张横版封面（1880x800，cover-s2h-01）
主题：零基础跑通第一套 Agent 评测（DeepEval，4 条用例 · 两种架构）
"""
import os, subprocess

OUT = os.path.expanduser("~/.openclaw/workspace/session-files/01M20S67DZSWEWWHNP370TWZVB/agent-testing-series/figs")
os.makedirs(OUT, exist_ok=True)

W, H = 1080, 1920
MX = 80
CW = W - MX * 2
BG = "#0e1730"
PANEL = "#16264a"
EDGE = "#2a4170"
ACCENT = "#ffb454"
BLUE = "#5b8def"
TXT = "#e8eefb"
SUB = "#9fb3d8"
DIM = "#6f87b5"
GREEN = "#4ec98a"
RED = "#ff7a7a"


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def T(x, y, s, size, fill, bold=False, anchor="start"):
    fw = ' font-weight="bold"' if bold else ''
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}"{fw} text-anchor="{anchor}">{esc(s)}</text>'


def header(n, total=10):
    return (T(MX, 64, "Agent 测试进阶实战（第二季）· 实战篇 01", 23, DIM)
            + f'<rect x="{W-MX-84}" y="34" width="84" height="44" rx="22" fill="{PANEL}" stroke="{EDGE}" stroke-width="2"/>'
            + T(W-MX-42, 64, f"{n}/{total}", 25, TXT, True, "middle"))


def wm():
    return (f'<rect x="{(W-320)//2}" y="1852" width="320" height="44" rx="22" fill="#1b2d55"/>'
            + T(W//2, 1882, "Python测试之道", 24, "#8fa6d6", True, "middle")
            + f'<g transform="rotate(-24 330 1500)" opacity="0.07">' + T(120, 1500, "Python测试之道", 118, "#ffffff", True) + '</g>'
            + f'<g transform="rotate(-24 720 1690)" opacity="0.05">' + T(520, 1710, "Python测试之道", 118, "#ffffff", True) + '</g>')


def title_block(y, lines, sub=None, size=62):
    s, cur = "", y
    for ln in lines:
        s += T(W//2, cur, ln, size, "#ffffff", True, "middle")
        cur += int(size * 1.3)
    if sub:
        cur += 4
        s += T(W//2, cur, sub, 31, SUB, anchor="middle")
        cur += 46
    s += f'<rect x="{(W-120)//2}" y="{cur}" width="120" height="6" rx="3" fill="{BLUE}"/>'
    return s, cur + 52


def note(y, label, lines, lh=50, size=32, edge="#3b6fd4", lcol=ACCENT):
    h = 82 + lh * len(lines)
    s = f'<rect x="{MX}" y="{y}" width="{CW}" height="{h}" rx="18" fill="#1d2f58" stroke="{edge}" stroke-width="2.5"/>'
    s += T(MX + 30, y + 44, label, 24, lcol, True)
    cy = y + 86
    for ln in lines:
        s += T(MX + 30, cy, ln, size, TXT)
        cy += lh
    return s, y + h + 40


def rows(y, items, size=29, lh=42, pad=30):
    s = ""
    for head, lines in items:
        head_y = y + pad + 32
        line1 = head_y + 46
        h = (line1 - y) + lh * (len(lines) - 1) + 40
        s += f'<rect x="{MX}" y="{y}" width="{CW}" height="{h}" rx="18" fill="{PANEL}" stroke="{EDGE}" stroke-width="2"/>'
        s += f'<circle cx="{MX+34}" cy="{head_y-10}" r="7" fill="{ACCENT}"/>'
        s += T(MX + 60, head_y, head, size + 1, TXT, True)
        cy = line1
        for ln in lines:
            s += T(MX + 60, cy, ln, 26, SUB)
            cy += lh
        y += h + 22
    return s, y


def code(y, lines, size=26, lh=40, label="代码"):
    h = 76 + lh * len(lines)
    s = f'<rect x="{MX}" y="{y}" width="{CW}" height="{h}" rx="16" fill="#0a1124" stroke="#243a63" stroke-width="2"/>'
    s += T(MX + 26, y + 44, label, 22, DIM, True)
    cy = y + 80
    for ln in lines:
        s += T(MX + 26, cy, ln, size, "#a7e0b8")
        cy += lh
    return s, y + h + 40


def build(elems, w=W, h=H, bg=BG):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'font-family="Noto Sans CJK SC, sans-serif">'
            f'<rect width="{w}" height="{h}" fill="{bg}"/>' + "".join(elems) + "</svg>")


def save(name, svg, w=W, h=H):
    ps = os.path.join(OUT, f"{name}-src.svg")
    pp = os.path.join(OUT, f"{name}.png")
    open(ps, "w", encoding="utf-8").write(svg)
    subprocess.run(["convert", "-background", "none", ps, pp], check=True)
    print("saved", pp)


# ============================================================ 10 张竖版贴图
pages = []

# ---- P1 封面 ----
e = [header(1)]
e.append('<rect x="230" y="196" width="620" height="54" rx="27" fill="#3b6fd4"/>')
e.append(T(W // 2, 231, "第二季 · 实战篇 01 贴图速读", 27, "#ffffff", True, "middle"))
t, y = title_block(350, ["零基础跑通", "第一套 Agent 评测"], "4 条用例 · 两种架构 · 全程可复现", size=64)
e.append(t)
y += 20
for i, kw in enumerate(["DeepEval", "pytest 体系", "留档可回溯"]):
    x0 = 70 + i * 325
    e.append(f'<rect x="{x0}" y="{y}" width="300" height="60" rx="30" fill="#22375f" stroke="#3b6fd4" stroke-width="2"/>')
    e.append(T(x0 + 150, y + 39, kw, 28, "#cfe0ff", True, "middle"))
y += 132
e.append(T(W // 2, y, "结果对 ≠ 过程对：评测要同时看这两样", 30, ACCENT, True, anchor="middle"))
e.append('<rect x="270" y="1580" width="540" height="140" rx="18" fill="#1b2d55" stroke="#3b6fd4" stroke-width="2"/>')
e.append(T(540, 1634, "single   4 passed", 34, GREEN, True, "middle"))
e.append(T(540, 1686, "subagents 4 passed", 34, GREEN, True, "middle"))
e.append(T(540, 1776, "Python测试之道 · 第二季实战篇 01", 23, DIM, anchor="middle"))
e.append(wm())
pages.append(build(e))

# ---- P2 立论 ----
e = [header(2)]
e.append(T(MX, 150, "先立论 · 为什么难测", 30, SUB))
t, y = title_block(210, ["结果对，", "不代表过程对"], size=66)
e.append(t)
s, y = rows(y, [
    ("结论对 · 过程错", ["它是猜的，没用工具查", "数据一变就错，你还不知道该改哪"]),
    ("结论错 · 过程对", ["工具调对了，是总结错了", "问题在提示词，不在数据"]),
], 0)
e.append(s)
n, y = note(y, "所以判据要变", ["旧：返回对不对", "新：最终输出 + 工具调用轨迹，一起看"], edge="#ffb454")
e.append(n)
e.append(T(MX, y, "这一条，是整套评测的地基。", 31, BLUE, True))
e.append(wm())
pages.append(build(e))

# ---- P3 四个零件 ----
e = [header(3)]
e.append(T(MX, 150, "一条用例 = 四个零件", 30, SUB))
t, y = title_block(210, ["拆开看，", "它其实很简单"], size=62)
e.append(t)
s, y = rows(y, [
    ("① 输入 input", ["用户会怎么问 —— 决定用例能不能复现"]),
    ("② 期望 expected", ["什么叫对：ground truth + 该调的工具"]),
    ("③ 证据 evidence", ["它到底调了什么工具（轨迹 tools_used）"]),
    ("④ 判定 judge", ["通过 / 失败，依据是什么"]),
], 0)
e.append(s)
n, y = note(y, "最容易漏的是 ③", ["没有轨迹证据，就只能退回到“只看输出”的老路", "也就漏掉了“结果对、过程错”这一半的 bug"])
e.append(n)
e.append(wm())
pages.append(build(e))

# ---- P4 可复现三件事 ----
e = [header(4)]
e.append(T(MX, 150, "让用例「可复现」的三件事", 30, SUB))
t, y = title_block(210, ["跑一次不算评测", "能重复才算"], size=60)
e.append(t)
s, y = rows(y, [
    ("① ground truth 有出处", ["期望值从种子数据推出来（P0=3 / blocker=2）", "换台机器、换个人跑，结论一致"]),
    ("② 独立会话 thread_id", ["每条用例一个新会话", "否则第二条带着第一条记忆 → 结果被污染"]),
    ("③ 证据回传", ["被测系统要能吐出工具调用轨迹", "评测端才判得了“过程对不对”"]),
], 0)
e.append(s)
e.append(wm())
pages.append(build(e))

# ---- P5 两层断言 ----
e = [header(5)]
e.append(T(MX, 150, "两层断言 · 先便宜后贵", 30, SUB))
t, y = title_block(210, ["规则能判死的", "绝不用裁判"], size=62)
e.append(t)
s, y = rows(y, [
    ("规则层（先跑）", ["确定性 / 零成本 / 先跑", "关键事实在不在、工具调没调、禁用内容有没有"]),
    ("指标层（后跑）", ["LLM 裁判 / 有成本 / 后跑", "答案相关性、任务完成质量这类主观维度"]),
], 0)
e.append(s)
n, y = note(y, "本期 4 条用例的成本账", ["2 条用指标（SQL、时间解析）", "2 条纯规则（天气越界、注入不泄露）"], edge="#4ec98a")
e.append(n)
e.append(T(MX, y, "省的不是钱，是“被裁判噪声带偏”的概率。", 29, ACCENT, True))
e.append(wm())
pages.append(build(e))

# ---- P6 动手 ----
e = [header(6)]
e.append(T(MX, 150, "动手 · 两条命令", 30, SUB))
t, y = title_block(210, ["环境装好，", "就两步"], size=62)
e.append(t)
s, y = code(y, [
    "pip install -r requirements.txt",
    "pip install -U deepeval",
    "python scripts/seed_test_db.py     # 造 ground truth",
], label="准备")
e.append(s)
s, y = code(y, [
    "pytest evals/test_agent_eval.py -m integration",
    "",
    "$env:EVAL_AGENT_MODE=\"subagents\"; pytest evals/... -m integration",
], label="跑评测（单 Agent / 多 Agent）")
e.append(s)
n, y = note(y, "为什么强调 -m integration", ["这类用例要调真实模型，标记出来便于分层执行", "PR 阶段跑规则、夜间跑全量"])
e.append(n)
e.append(wm())
pages.append(build(e))

# ---- P7 实证 single ----
e = [header(7)]
e.append(T(MX, 150, "实证 ① · 单 Agent", 30, SUB))
t, y = title_block(210, ["4 passed", "24.85s"], size=68)
e.append(t)
s, y = code(y, [
    "> pytest evals/test_agent_eval.py -m integration",
    "evals\\test_agent_eval.py ....        [100%]",
    "4 passed, 1 warning in 24.85s",
], label="Windows · Python 3.13 · deepeval 4.2.3")
e.append(s)
n, y = note(y, "4 条用例", ["SQL 数量（=3）｜时间解析（15:00）", "天气越界不编造｜注入不泄露"], edge="#4ec98a")
e.append(n)
e.append(T(MX, y, "指标：过程正确 1.0 · 完成度 1.0 · 平均 1.000", 29, GREEN, True))
e.append(wm())
pages.append(build(e))

# ---- P8 实证 subagents ----
e = [header(8)]
e.append(T(MX, 150, "实证 ② · 多 Agent 分工", 30, SUB))
t, y = title_block(210, ["4 passed", "32.40s"], size=68)
e.append(t)
s, y = code(y, [
    "> $env:EVAL_AGENT_MODE=\"subagents\"; pytest ...",
    "evals\\test_agent_eval.py ....        [100%]",
    "4 passed, 1 warning in 32.40s",
], label="Supervisor + 子 Agent")
e.append(s)
n, y = note(y, "同一套用例，换架构也过", ["single：tools_used = [parse_natural_datetime]", "subagents：[time_specialist, parse_natural_datetime]"], edge="#5b8def")
e.append(n)
e.append(T(MX, y, "所以工具断言要用“包含”，不能用“相等”。", 29, ACCENT, True))
e.append(wm())
pages.append(build(e))

# ---- P9 四个坑 ----
e = [header(9)]
e.append(T(MX, 150, "实战 · 四个坑", 30, SUB))
t, y = title_block(210, ["都是真踩过的"], size=64)
e.append(t)
s, y = rows(y, [
    ("坑 1 · 提示词被忽略", ["加载器只认 .txt、提示词却是 .md → 评测全白跑"]),
    ("坑 2 · 类型不对", ["tools_called 要是 ToolCall 对象，传字符串直接报错"]),
    ("坑 3 · 裁判偷偷走 OpenAI", ["不传 model，指标默认初始化 OpenAI 裁判 → 报错"]),
    ("坑 4 · 断言绑死架构", ["== 相等换个架构就假失败 → 改 in 包含"]),
], 0)
e.append(s)
e.append(T(MX, y, "共同点：都不是“产品错了”，是“评测配错了”。", 28, ACCENT, True))
e.append(wm())
pages.append(build(e))

# ---- P10 隐藏缺陷 + 留档 + CTA ----
e = [header(10)]
e.append(T(MX, 150, "最阴的一条 · 留档闭环", 30, SUB))
t, y = title_block(210, ["评测失败 ≠ 产品有缺陷"], size=60)
e.append(t)
s, y = rows(y, [
    ("表象", ["多 Agent 下 SQL 用例时好时坏（INVALID_SUBAGENT_RESULT）"]),
    ("抓状态后", ["失败时最后一条是空 AI 消息：模型忘了调结构化输出工具"]),
    ("结论 + 修法", ["模型抖动，不是查询错 → 加一次重试，2/3 失败变 0/3"]),
], 0)
e.append(s)
n, y = note(y, "再补一刀：把分数留档", ["默认只看 PASS/FAIL，看不到分数和裁判理由", "留档成 JSON → 失败能回溯，多次运行能比趋势"], edge="#ffb454")
e.append(n)
e.append('<rect x="240" y="1560" width="600" height="150" rx="18" fill="#1b2d55" stroke="#ffb454" stroke-width="2.5"/>')
e.append(T(540, 1612, "完整源码 · 后台回复「agent」", 30, "#ffffff", True, "middle"))
e.append(T(540, 1662, "夸克网盘 · 含 Seed 数据与评测配置", 26, ACCENT, True, "middle"))
e.append(T(540, 1730, "点赞 · 在看 · 转发", 25, SUB, anchor="middle"))
e.append(wm())
pages.append(build(e))

for i, svg in enumerate(pages, 1):
    save(f"sticker-s2h-{i:02d}", svg)

# ============================================================ 3 张文章配图
FW, FH = 1600, 1000
FX = 70
FCW = FW - FX * 2

# ---- fig A：用例解剖 ----
e = [T(FX, 70, "图 A · 一条 Agent 评测用例的四个零件", 34, "#ffffff", True)]
e.append(T(FX, 122, "输入 → 期望 → 证据 → 判定；少了任何一个零件，评测都不可复现", 24, SUB))
cards = [
    ("① 输入", ["用户问法", "决定可否复现"], "#5b8def"),
    ("② 期望", ["ground truth", "该调的工具"], "#ffb454"),
    ("③ 证据", ["tools_used", "工具调用轨迹"], "#4ec98a"),
    ("④ 判定", ["规则断言", "LLM 指标"], "#b07aff"),
]
cw = (FCW - 3 * 26) // 4
for i, (head, lines, col) in enumerate(cards):
    x = FX + i * (cw + 26)
    e.append(f'<rect x="{x}" y="210" width="{cw}" height="250" rx="18" fill="{PANEL}" stroke="{col}" stroke-width="3"/>')
    e.append(T(x + cw // 2, 280, head, 34, col, True, "middle"))
    cy = 340
    for ln in lines:
        e.append(T(x + cw // 2, cy, ln, 24, TXT, anchor="middle"))
        cy += 40
    if i < 3:
        e.append(T(x + cw + 13, 345, "→", 34, DIM, True, "middle"))
e.append(f'<rect x="{FX}" y="510" width="{FCW}" height="190" rx="18" fill="#1d2f58" stroke="#3b6fd4" stroke-width="2.5"/>')
e.append(T(FX + 30, 560, "对照代码（本期 SQL 用例）", 24, ACCENT, True))
for i, ln in enumerate([
    'query = "当前一共有多少条 P0 优先级的测试用例？"     # ① 输入',
    'assert "3" in result["answer"]                        # ② 期望（种子数据）',
    'tools_called=[ToolCall(name=t) for t in result["tools_used"]]   # ③ 证据',
    'assert_test(case, [ToolCorrectnessMetric(...), TaskCompletionMetric(...)])  # ④ 判定',
]):
    e.append(T(FX + 30, 606 + i * 34, ln, 21, "#a7e0b8"))
e.append(f'<rect x="{FX}" y="740" width="{FCW}" height="180" rx="18" fill="#16264a" stroke="#2a4170" stroke-width="2"/>')
e.append(T(FX + 30, 790, "两层断言：规则先跑、指标后跑", 24, ACCENT, True))
e.append(T(FX + 30, 838, "规则层（零成本）：关键事实 / 工具路由 / 禁泄露 → 判死 2 条用例", 23, TXT))
e.append(T(FX + 30, 880, "指标层（有成本）：过程正确性 + 任务完成度（阈值 0.7） → 2 条用例", 23, TXT))
e.append(T(FX + 30, 906, "成本控制 + 准确度控制，一次搞定", 22, SUB))
e.append(T(FW - FX, 968, "Python测试之道 · 第二季实战篇 01", 22, DIM, False, "end"))
save("fig-s2h-a", build(e, FW, FH))

# ---- fig B：双架构 A/B ----
e = [T(FX, 70, "图 B · 同一套用例，两种架构（实测都 4 passed）", 34, "#ffffff", True)]
e.append(T(FX, 122, "评测要跟架构解耦：断言写“包含”，不写“相等”", 24, SUB))
e.append(f'<rect x="{FX}" y="200" width="{FCW}" height="300" rx="18" fill="{PANEL}" stroke="#4ec98a" stroke-width="3"/>')
e.append(T(FX + 30, 254, "single · 单 Agent", 30, GREEN, True))
e.append(T(FX + 30, 300, "pytest evals/test_agent_eval.py -m integration", 23, "#a7e0b8"))
e.append(T(FX + 30, 350, "4 passed, 1 warning in 24.85s", 27, "#ffffff", True))
e.append(T(FX + 30, 402, "用户 → Agent → 业务工具（直接调）", 24, TXT))
e.append(T(FX + 30, 446, 'tools_used = ["parse_natural_datetime"]', 22, ACCENT))
e.append(f'<rect x="{FX}" y="530" width="{FCW}" height="300" rx="18" fill="{PANEL}" stroke="#5b8def" stroke-width="3"/>')
e.append(T(FX + 30, 584, "subagents · Supervisor + 子 Agent", 30, BLUE, True))
e.append(T(FX + 30, 630, '$env:EVAL_AGENT_MODE="subagents"; pytest ...', 23, "#a7e0b8"))
e.append(T(FX + 30, 680, "4 passed, 1 warning in 32.40s", 27, "#ffffff", True))
e.append(T(FX + 30, 732, "用户 → Supervisor → 时间/文件/SQL 子 Agent", 24, TXT))
e.append(T(FX + 30, 776, 'tools_used = ["time_specialist", "parse_natural_datetime"]', 22, ACCENT))
e.append(f'<rect x="{FX}" y="870" width="{FCW}" height="90" rx="16" fill="#1d2f58" stroke="#ffb454" stroke-width="2"/>')
e.append(T(FX + 30, 910, "结论：同一套用例换架构仍全绿 —— 前提是工具断言用 in 而不是 ==", 24, "#ffffff", True))
e.append(T(FX + 30, 944, "多出的 time_specialist 是主管层的“包装工具”，不是多余调用。", 22, SUB))
save("fig-s2h-b", build(e, FW, FH))

# ---- fig C：实施闭环 ----
e = [T(FX, 70, "图 C · 实施闭环：从敲命令到可回溯", 34, "#ffffff", True)]
e.append(T(FX, 122, "跑通只是起点；留档 + 对比趋势，才叫“评测体系”", 24, SUB))
steps = [
    ("① 造数据", ["python scripts/seed_test_db.py", "P0=3 / blocker=2"], "#5b8def"),
    ("② 跑用例", ["pytest ... -m integration", "single / subagents"], "#ffb454"),
    ("③ 出指标", ["ToolCorrectness /", "TaskCompletion ≥ 0.7"], "#4ec98a"),
    ("④ 留档", ["reports/eval-*.json", "分数 + 裁判理由"], "#b07aff"),
]
cw = (FCW - 3 * 22) // 4
for i, (head, lines, col) in enumerate(steps):
    x = FX + i * (cw + 22)
    e.append(f'<rect x="{x}" y="210" width="{cw}" height="220" rx="18" fill="{PANEL}" stroke="{col}" stroke-width="3"/>')
    e.append(T(x + cw // 2, 276, head, 30, col, True, "middle"))
    cy = 332
    for ln in lines:
        e.append(T(x + cw // 2, cy, ln, 21, TXT, anchor="middle"))
        cy += 36
    if i < 3:
        e.append(T(x + cw + 11, 330, "→", 32, DIM, True, "middle"))
e.append(f'<rect x="{FX}" y="480" width="{FCW}" height="250" rx="18" fill="#0a1124" stroke="#243a63" stroke-width="2"/>')
e.append(T(FX + 28, 528, "留档长这样（终端表格 + JSON）", 24, ACCENT, True))
for i, ln in enumerate([
    "指标                      score    阈值    结果    裁判理由",
    "ToolCorrectnessMetric     1.000    0.700   通过    All expected tools were called...",
    "TaskCompletionMetric      1.000    0.700   通过    ...the exact count (3)... aligning",
    "[评测汇总] 架构=single 用例=4 指标通过=4/4 平均分=1.000",
]):
    e.append(T(FX + 28, 576 + i * 34, ln, 21, "#a7e0b8"))
e.append(f'<rect x="{FX}" y="770" width="{FCW}" height="150" rx="18" fill="#16264a" stroke="#2a4170" stroke-width="2"/>')
e.append(T(FX + 30, 820, "为什么非要留档？", 24, ACCENT, True))
e.append(T(FX + 30, 866, "① 失败时知道裁判为什么扣分；② 多次运行能比分数趋势 —— 这才是评测回归。", 23, TXT))
e.append(T(FX + 30, 900, "只看 PASS/FAIL 的评测，跑完仍是个黑盒。", 22, SUB))
e.append(T(FW - FX, 968, "Python测试之道 · 第二季实战篇 01", 22, DIM, False, "end"))
save("fig-s2h-c", build(e, FW, FH))

# ============================================================ 横版封面
CW2, CH2 = 1880, 800
e = ['<rect width="1880" height="800" fill="#0b1226"/>']
e.append('<rect x="0" y="0" width="1880" height="8" fill="#3b6fd4"/>')
e.append(T(90, 150, "Agent 测试进阶实战（第二季）· 实战篇 01", 30, "#8fa6d6"))
e.append(T(90, 300, "零基础跑通第一套 Agent 评测", 78, "#ffffff", True))
e.append(T(90, 396, "4 条用例 · 两种架构 · 从「结果对≠过程对」讲起", 36, "#9fb3d8"))
e.append('<rect x="90" y="452" width="150" height="6" rx="3" fill="#ffb454"/>')
for i, kw in enumerate(["DeepEval 指标断言", "pytest 融入 CI", "分数与理由留档"]):
    x0 = 90 + i * 380
    e.append(f'<rect x="{x0}" y="520" width="350" height="66" rx="33" fill="#16264a" stroke="#2a4170" stroke-width="2"/>')
    e.append(T(x0 + 175, 562, kw, 28, "#cfe0ff", True, "middle"))
e.append('<rect x="1360" y="470" width="440" height="150" rx="20" fill="#16264a" stroke="#4ec98a" stroke-width="2.5"/>')
e.append(T(1580, 528, "single    4 passed", 30, GREEN, True, "middle"))
e.append(T(1580, 580, "subagents  4 passed", 30, GREEN, True, "middle"))
e.append(T(90, 700, "公众号：Python测试之道   ·   源码领取：后台回复「agent」", 30, "#ffb454", True))
e.append('<g transform="rotate(-24 1500 300)" opacity="0.06">' + T(1180, 300, "Python测试之道", 130, "#ffffff", True) + '</g>')
e.append('<g transform="rotate(-24 1600 640)" opacity="0.05">' + T(1250, 660, "Python测试之道", 130, "#ffffff", True) + '</g>')
save("cover-s2h-01", build(e, CW2, CH2, "#0b1226"), CW2, CH2)

print("all done")
