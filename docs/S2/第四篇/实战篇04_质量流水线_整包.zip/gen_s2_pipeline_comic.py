#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""番外篇 · 漫画风贴图 v2（漫说测试）：
   字号加大 · 气泡重做 · 内容铺满版面
   - 10 张竖版贴图（1080x1920，sticker-s2xc-01..10）
   - 1 张横版封面（1880x800，cover-s2xc-01）
字体：ZCOOL KuaiLe（站酷快乐体） 渲染：rsvg-convert
"""
import os, subprocess

OUT = os.path.expanduser("~/.openclaw/workspace/session-files/01M20S67DZSWEWWHNP370TWZVB/agent-testing-series/figs")
os.makedirs(OUT, exist_ok=True)

W, H = 1080, 1920
MX, CW = 60, 960
INK = "#1F1B16"
PAPER = "#FFF6E5"
WHT = "#FFFFFF"
YEL = "#FFD93D"
RED = "#FF6B6B"
BLU = "#4D8BFF"
GRN = "#3FBF63"
PUR = "#9B5DFF"
SKIN = "#FFE0B2"
FONT = "ZCOOL KuaiLe, Noto Sans CJK SC"

# 字号基线（v2 全面加大）
F_H1 = 96      # 主标题
F_H2 = 64      # 副标题
F_CHAP = 44    # 话数标签
F_BUB = 46     # 气泡正文
F_CT = 48      # 卡片标题
F_CB = 38      # 卡片正文
F_CS = 32      # 卡片小字
F_LEAD = 60    # 金句


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def T(x, y, s, size, fill=INK, anchor="start", rot=None, sw=0, swc=INK, sp=0):
    tr = f' transform="rotate({rot} {x} {y})"' if rot else ''
    st = f' stroke="{swc}" stroke-width="{sw}" paint-order="stroke"' if sw else ''
    ls = f' letter-spacing="{sp}"' if sp else ''
    return (f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" text-anchor="{anchor}"'
            f' font-family="{FONT}"{tr}{st}{ls}>{esc(s)}</text>')


def panel(x, y, w, h, fill=WHT, sw=7, rot=None, dash=None):
    tr = f' transform="rotate({rot} {x+w/2} {y+h/2})"' if rot else ''
    d = f' stroke-dasharray="{dash}"' if dash else ''
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="30" fill="{fill}"'
            f' stroke="{INK}" stroke-width="{sw}"{d}{tr}/>')


def card(y, h, fill=WHT, x=MX, w=CW, sw=7):
    return panel(x, y, w, h, fill, sw)


def bubble(x, y, w, h, lines, size=F_BUB, tail="bl", fill=WHT, lh=None):
    """对话气泡 v2：单条干净尾巴 + 更宽内边距"""
    lh = lh or int(size * 1.46)
    s = panel(x, y, w, h, fill, 7)
    pad = 46
    if tail == "bl":
        bx0, bx1 = x + 52, x + 168
        s += (f'<path d="M {bx0} {y+h-10} L {bx0+10} {y+h+66} L {bx1} {y+h-10} Z" fill="{fill}"'
              f' stroke="{INK}" stroke-width="7" stroke-linejoin="round"/>'
              f'<rect x="{bx0+8}" y="{y+h-16}" width="{bx1-bx0-16}" height="12" fill="{fill}"/>')
    elif tail == "br":
        bx0, bx1 = x + w - 168, x + w - 52
        s += (f'<path d="M {bx0} {y+h-10} L {bx1-10} {y+h+66} L {bx1} {y+h-10} Z" fill="{fill}"'
              f' stroke="{INK}" stroke-width="7" stroke-linejoin="round"/>'
              f'<rect x="{bx0+8}" y="{y+h-16}" width="{bx1-bx0-16}" height="12" fill="{fill}"/>')
    elif tail == "tr":
        bx0, bx1 = x + w - 190, x + w - 60
        s += (f'<path d="M {bx0} {y+10} L {bx1-6} {y-64} L {bx1} {y+10} Z" fill="{fill}"'
              f' stroke="{INK}" stroke-width="7" stroke-linejoin="round"/>'
              f'<rect x="{bx0+8}" y="{y+4}" width="{bx1-bx0-16}" height="12" fill="{fill}"/>')
    cy = y + pad + int(size * 0.82)
    for ln in lines:
        s += T(x + pad, cy, ln, size)
        cy += lh
    return s


def cloud(x, y, w, h, lines, size=38, lh=54):
    s = (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{h//2}" fill="{WHT}"'
         f' stroke="{INK}" stroke-width="6" stroke-dasharray="16 11"/>')
    s += f'<circle cx="{x+46}" cy="{y+h+34}" r="16" fill="{WHT}" stroke="{INK}" stroke-width="6"/>'
    s += f'<circle cx="{x+18}" cy="{y+h+72}" r="10" fill="{WHT}" stroke="{INK}" stroke-width="6"/>'
    cy = y + 62
    for ln in lines:
        s += T(x + 44, cy, ln, size)
        cy += lh
    return s


def sfx(x, y, text, size=64, rot=-14, col=RED, sw=4):
    return T(x, y, text, size, col, rot=rot, sw=sw, swc=INK)


def badge(x, y, text, fill=YEL, size=36, pad=40, h=68, anchor="start"):
    w = int(len(text) * size * 0.96 + pad * 2)
    if anchor == "middle":
        x = x - w // 2
    return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{h//2}" fill="{fill}" stroke="{INK}" stroke-width="6"/>'
            + T(x + w // 2, y + h // 2 + size // 3, text, size, INK, anchor="middle"))


def mascot(cx, cy, s=1.0, mood="happy", clothes=BLU):
    """小测试员（v2：线条加粗）"""
    g = [f'<g transform="translate({cx} {cy}) scale({s})">']
    g.append(f'<rect x="-46" y="150" width="32" height="88" rx="15" fill="#3B4A6B" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<rect x="14" y="150" width="32" height="88" rx="15" fill="#3B4A6B" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<rect x="-70" y="52" width="140" height="112" rx="34" fill="{clothes}" stroke="{INK}" stroke-width="7"/>')
    al = '-120,116 -86,84' if mood in ("yeah", "happy") else '-126,96 -84,120'
    g.append(f'<polyline points="{al}" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>')
    g.append(f'<polyline points="86,84 120,116" fill="none" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>')
    g.append(f'<circle cx="-128" cy="{80 if mood in ("yeah","happy") else 92}" r="21" fill="{SKIN}" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<circle cx="128" cy="92" r="21" fill="{SKIN}" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<circle cx="0" cy="-6" r="80" fill="{SKIN}" stroke="{INK}" stroke-width="7"/>')
    g.append(f'<path d="M -80 -22 A 80 80 0 0 1 80 -22 Q 42 -76 0 -68 Q -42 -76 -80 -22 Z" fill="{INK}"/>')
    if mood == "cool":
        g.append(f'<rect x="-60" y="-32" width="48" height="28" rx="9" fill="{INK}"/>')
        g.append(f'<rect x="12" y="-32" width="48" height="28" rx="9" fill="{INK}"/>')
        g.append(f'<path d="M -60 -32 L -12 -32 M 12 -32 L 60 -32" stroke="{INK}" stroke-width="7"/>')
    elif mood == "shock":
        g.append(f'<circle cx="-27" cy="-14" r="14" fill="{WHT}" stroke="{INK}" stroke-width="6"/>')
        g.append(f'<circle cx="27" cy="-14" r="14" fill="{WHT}" stroke="{INK}" stroke-width="6"/>')
        g.append(f'<circle cx="-27" cy="-14" r="6" fill="{INK}"/>')
        g.append(f'<circle cx="27" cy="-14" r="6" fill="{INK}"/>')
    else:
        g.append(f'<circle cx="-27" cy="-14" r="10" fill="{INK}"/>')
        g.append(f'<circle cx="27" cy="-14" r="10" fill="{INK}"/>')
        g.append(f'<circle cx="-24" cy="-17" r="3.4" fill="{WHT}"/>')
        g.append(f'<circle cx="30" cy="-17" r="3.4" fill="{WHT}"/>')
    g.append(f'<ellipse cx="-52" cy="16" rx="16" ry="10" fill="{RED}" opacity="0.5"/>')
    g.append(f'<ellipse cx="52" cy="16" rx="16" ry="10" fill="{RED}" opacity="0.5"/>')
    if mood == "shock":
        g.append(f'<ellipse cx="0" cy="38" rx="18" ry="22" fill="{INK}"/>')
    elif mood == "sweat":
        g.append(f'<path d="M -26 40 q 13 13 26 0 q 13 -13 26 0" fill="none" stroke="{INK}" stroke-width="7"/>')
    elif mood == "think":
        g.append(f'<path d="M -22 40 q 22 9 44 -2" fill="none" stroke="{INK}" stroke-width="7"/>')
    elif mood == "cool":
        g.append(f'<path d="M -28 36 q 28 17 56 -7" fill="none" stroke="{INK}" stroke-width="7"/>')
    else:
        g.append(f'<path d="M -30 32 q 30 36 60 0" fill="none" stroke="{INK}" stroke-width="8"/>')
    if mood == "sweat":
        g.append(f'<path d="M 70 -50 q 15 24 0 32 q -15 -8 0 -32 Z" fill="{BLU}" stroke="{INK}" stroke-width="5"/>')
    g.append('</g>')
    return "".join(g)


def head(n):
    return (f'<rect x="0" y="0" width="{W}" height="100" fill="{YEL}"/>'
            f'<line x1="0" y1="100" x2="{W}" y2="100" stroke="{INK}" stroke-width="7"/>'
            + T(36, 68, "漫说测试 · 番外篇", 36)
            + T(W - 36, 68, f"{n}/10", 38, anchor="end"))


def wmc():
    return (f'<rect x="{(W-400)//2}" y="1830" width="400" height="62" rx="31" fill="{WHT}" stroke="{INK}" stroke-width="6"/>'
            + T(W // 2, 1874, "Python测试之道", 34, anchor="middle"))


def build(elems, w=W, h=H):
    defs = (f'<defs><pattern id="dots" width="28" height="28" patternUnits="userSpaceOnUse">'
            f'<circle cx="5" cy="5" r="2.6" fill="{INK}" opacity="0.09"/></pattern></defs>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'font-family="{FONT}">' + defs + f'<rect width="{w}" height="{h}" fill="{PAPER}"/>'
            f'<rect width="{w}" height="{h}" fill="url(#dots)"/>' + "".join(elems) + "</svg>")


def save(name, svg, w=W, h=H):
    ps = os.path.join(OUT, f"{name}-src.svg")
    pp = os.path.join(OUT, f"{name}.png")
    open(ps, "w", encoding="utf-8").write(svg)
    subprocess.run(["rsvg-convert", ps, "-o", pp], check=True)
    print("saved", pp)


def kv(y, items, h=None, fill=WHT, size=F_CB, lh=64, title=None, tcol=INK):
    """按行铺满的卡片：items=[(标签, 值)]；返回 (svg, 卡片高度)"""
    n = len(items)
    hh = h or (150 + lh * n if title else 120 + lh * n)
    s = card(y, hh, fill)
    cy = y + 78
    if title:
        s += T(MX + 44, cy, title, F_CT, tcol)
        cy += 76
    for a, b in items:
        s += f'<circle cx="{MX+62}" cy="{cy-14}" r="15" fill="{GRN}" stroke="{INK}" stroke-width="5"/>'
        s += T(MX + 100, cy, a, size)
        if b:
            s += T(MX + CW - 44, cy, b, int(size * 0.72), "#6B6257", anchor="end")
        cy += lh
    return s, hh



# ============================================================ 实战篇 04 覆盖标题条
def head(n):  # noqa: F811 —— 覆盖助手里的通用标题条
    return (f'<rect x="0" y="0" width="{W}" height="100" fill="{YEL}"/>'
            f'<line x1="0" y1="100" x2="{W}" y2="100" stroke="{INK}" stroke-width="7"/>'
            + T(36, 68, "漫说测试 · 实战篇 04", 36)
            + T(W - 36, 68, f"{n}/10", 38, anchor="end"))


# ============================================================ 10 张贴图
P = []

# ---- 1 封面 ----
e = [head(1)]
e.append(badge(W // 2, 150, "漫说测试 · 实战篇 04", YEL, 42, anchor="middle"))
e.append(T(W // 2, 330, "质量流水线", 100, INK, anchor="middle"))
e.append(T(W // 2, 470, "评测 · 追踪 · 监控", 76, BLU, anchor="middle", sw=3))
e.append(bubble(70, 550, 620, 200, ["工具都齐了", "为什么还是乱？"], 46, "bl"))
e.append(mascot(830, 900, 1.16, "think"))
e.append(card(1120, 340, WHT))
e.append(T(MX + 44, 1210, "网关 · 取证 · 趋势", F_CT))
e.append(T(MX + 44, 1300, "三层职责，别混着用", F_CT, BLU))
e.append(T(MX + 44, 1390, "顺序对了，乱就消失", F_CS, "#6B6257"))
e.append(card(1500, 300, YEL))
e.append(T(MX + 44, 1590, "问题不在工具，在流程", 44))
e.append(T(MX + 44, 1680, "这篇讲：出问题先看哪个", 36))
e.append(T(MX + 44, 1750, "全套 9 话 · 读完约 4 分钟", 30, "#6B5744"))
e.append(wmc())
P.append(build(e))

# ---- 2 为什么还是乱 ----
e = [head(2)]
e.append(T(MX, 190, "第 1 话 · 工具齐了，还是乱", F_CHAP, "#6B6257"))
e.append(card(250, 570, WHT))
e.append(T(MX + 44, 350, "你可能每天都在经历", F_CT))
for i, ln in enumerate(["评测报告一堆，红灯照发", "出了问题，不知先看哪个", "夜里评测没人看", "分数慢慢掉，没人发现"]):
    e.append(f'<circle cx="{MX+62}" cy="{552 + i*80 - 14}" r="15" fill="{RED}" stroke="{INK}" stroke-width="5"/>')
    e.append(T(MX + 100, 552 + i * 80, ln, 36))
e.append(mascot(230, 1010, 0.78, "sweat"))
e.append(bubble(440, 880, 580, 190, ["问题不在工具", "在流程"], 46, "bl"))
e.append(card(1210, 280, "#FFF3F3"))
e.append(T(MX + 44, 1300, "工具解决“能不能看见”", 40))
e.append(T(MX + 44, 1386, "流程解决“看见了怎么办”", 40, RED))
e.append(card(1520, 260, YEL))
e.append(T(MX + 44, 1620, "把三样串成一条线", 42))
e.append(T(MX + 44, 1700, "再定清楚“先看哪个”", 36, "#6B5744"))
e.append(wmc())
P.append(build(e))

# ---- 3 三层职责 ----
e = [head(3)]
e.append(T(MX, 190, "第 2 话 · 三层职责", F_CHAP, "#6B6257"))
e.append(card(250, 380, WHT))
e.append(T(MX + 44, 340, "① 质量网关 · DeepEval", F_CT, BLU))
e.append(T(MX + 44, 430, "能不能放行？", 38))
e.append(T(MX + 44, 510, "每次 PR / 每晚 / 发版前", 32, "#6B6257"))
e.append(card(660, 380, WHT))
e.append(T(MX + 44, 750, "② 现场取证 · Langfuse", F_CT, GRN))
e.append(T(MX + 44, 840, "这次为什么这样？", 38))
e.append(T(MX + 44, 920, "出问题时随时查", 32, "#6B6257"))
e.append(card(1070, 380, WHT))
e.append(T(MX + 44, 1160, "③ 长期趋势 · 监控看板", F_CT, PUR))
e.append(T(MX + 44, 1250, "是不是在慢慢变坏？", 38))
e.append(T(MX + 44, 1330, "7×24 盯着", 32, "#6B6257"))
e.append(card(1480, 300, "#EAF3FF"))
e.append(T(MX + 44, 1570, "三层是漏斗，不是并列", 40, BLU))
e.append(T(MX + 44, 1650, "顺序乱了，工具就白买", 34, "#6B6257"))
e.append(wmc())
P.append(build(e))

# ---- 4 流水线全景 ----
e = [head(4)]
e.append(T(MX, 190, "第 3 话 · 流水线全景", F_CHAP, "#6B6257"))
flow = [("① 本地提交", "跑规则层：零成本、秒级", BLU),
        ("② PR 门禁", "规则层不可退让 + 关键用例", GRN),
        ("③ 合并后", "夜间全量评测 + 门禁判定", YEL),
        ("④ 发版前", "关键集 + 人工复核低分项", PUR),
        ("⑤ 线上", "追踪采样 + 异常回流评测集", RED)]
for i, (a, b, col) in enumerate(flow):
    y = 250 + i * 280
    e.append(card(y, 230, WHT))
    e.append(f'<rect x="{MX+20}" y="{y+20}" width="14" height="190" rx="7" fill="{col}"/>')
    e.append(T(MX + 60, y + 106, a, 44))
    e.append(T(MX + 60, y + 176, b, 32, "#6B6257"))
e.append(card(1670, 140, "#EAF7EE"))
e.append(T(MX + 44, 1760, "越靠近提交越便宜，越靠近上线越全面", 34, "#2F7A45"))
e.append(wmc())
P.append(build(e))

# ---- 5 成本曲线 ----
e = [head(5)]
e.append(T(MX, 190, "第 4 话 · 为什么必须分层", F_CHAP, "#6B6257"))
e.append(mascot(200, 440, 0.78, "cool"))
e.append(bubble(410, 270, 610, 190, ["不是好看", "是为了跑得起"], 42, "bl"))
cost = [("规则断言", "0 成本 · 毫秒 · 每次提交", GRN),
        ("结构 / 路由断言", "极低 · 秒级 · 每个 PR", BLU),
        ("LLM 裁判指标", "有成本 · 分钟级 · 抽样 / 夜间", RED)]
for i, (a, b, col) in enumerate(cost):
    y = 560 + i * 270
    e.append(card(y, 220, WHT))
    e.append(f'<circle cx="{MX+70}" cy="{y+110}" r="34" fill="{col}" stroke="{INK}" stroke-width="6"/>')
    e.append(T(MX + 140, y + 94, a, 42))
    e.append(T(MX + 140, y + 162, b, 32, "#6B6257"))
e.append(card(1410, 380, YEL))
e.append(T(MX + 44, 1540, "裁判很贵，规则很便宜", 44))
e.append(T(MX + 44, 1630, "能用规则判死的，绝不上裁判", 36, "#6B5744"))
e.append(T(MX + 44, 1710, "—— 这就是分层的全部理由", 32, "#6B5744"))
e.append(wmc())
P.append(build(e))

# ---- 6 门禁落地 ----
e = [head(6)]
e.append(T(MX, 190, "第 5 话 · 把门禁写进 CI", F_CHAP, "#6B6257"))
e.append(card(250, 400, "#0F172A"))
e.append(T(MX + 40, 350, "python scripts/quality_gate.py \\", 30, "#9BE7B0"))
e.append(T(MX + 60, 414, "reports/eval-single-*.json \\", 30, "#9BE7B0"))
e.append(T(MX + 60, 478, "--min-metrics-pass-rate 0.95 \\", 30, "#9BE7B0"))
e.append(T(MX + 60, 542, "--min-avg-score 0.80 \\", 30, "#9BE7B0"))
e.append(T(MX + 60, 606, "--baseline 昨天.json", 30, "#9BE7B0"))
e.append(card(700, 480, WHT))
e.append(T(MX + 44, 800, "四条判定，任一不满足就红", F_CT))
for i, ln in enumerate(["① 指标通过率 ≥ 阈值", "② 平均分 ≥ 阈值", "③ 不得比基线明显下降", "④ 不通过用例数 ≤ 允许值"]):
    e.append(f'<circle cx="{MX+62}" cy="{878 + i*74 - 14}" r="15" fill="{BLU}" stroke="{INK}" stroke-width="5"/>')
    e.append(T(MX + 100, 878 + i * 74, ln, 36))
e.append(card(1210, 300, "#EAF3FF"))
e.append(T(MX + 44, 1310, "留档是给人看的", 40))
e.append(T(MX + 44, 1400, "门禁是给机器判的", 40, BLU))
e.append(card(1540, 250, YEL))
e.append(T(MX + 44, 1636, "CI：PR 跑规则层，夜里跑全量", 38))
e.append(T(MX + 44, 1714, "判定不过 → 直接拦住", 34, "#6B5744"))
e.append(wmc())
P.append(build(e))

# ---- 7 门禁真的会拦 ----
e = [head(7)]
e.append(T(MX, 190, "第 6 话 · 最阴的那种情况", F_CHAP, "#6B6257"))
e.append(mascot(210, 440, 0.76, "shock"))
e.append(bubble(420, 270, 600, 190, ["全都过了！", "然后呢？"], 44, "bl"))
e.append(card(790, 400, "#FFF3F3"))
e.append(T(MX + 44, 890, "分数从 0.95 悄悄掉到 0.82", 40, RED))
e.append(T(MX + 44, 980, "但没有一条跌破阈值", 40))
e.append(T(MX + 44, 1060, "→ 只看红绿灯，你完全发现不了", 34, "#6B6257"))
e.append(card(1220, 330, WHT))
e.append(T(MX + 44, 1320, "必须对比基线", F_CT))
e.append(T(MX + 44, 1410, "平均分下降 0.113 ＞ 允许 0.050", 34, RED))
e.append(T(MX + 44, 1490, "→ 门禁拦下 ✅", 36, GRN))
e.append(card(1580, 200, "#EAF7EE"))
e.append(T(MX + 44, 1700, "上一期的留档，是这一期的弹药", 38, "#2F7A45"))
e.append(wmc())
P.append(build(e))

# ---- 8 分诊顺序 ----
e = [head(8)]
e.append(T(MX, 190, "第 7 话 · 出问题先看哪个", F_CHAP, "#6B6257"))
triage = [("PR 门禁红了", "先看评测 → 再看追踪", BLU),
          ("线上监控告警", "先看追踪 → 再看评测", GRN),
          ("用户说答得不对", "先看追踪 → 固化成用例", PUR),
          ("用户说太慢了", "先看追踪 → 再看监控", RED)]
for i, (a, b, col) in enumerate(triage):
    y = 250 + i * 250
    e.append(card(y, 210, WHT))
    e.append(f'<rect x="{MX+18}" y="{y+18}" width="14" height="174" rx="7" fill="{col}"/>')
    e.append(T(MX + 56, y + 100, a, 42))
    e.append(T(MX + 56, y + 166, b, 32, "#6B6257"))
e.append(card(1270, 320, YEL))
e.append(T(MX + 44, 1370, "每次线上问题的终点", 42))
e.append(T(MX + 44, 1460, "是一条新的评测用例", 42, RED))
e.append(T(MX + 44, 1540, "这样评测集才是“踩过的坑的集合”", 30, "#6B5744"))
e.append(card(1610, 180, "#EAF3FF"))
e.append(T(MX + 44, 1720, "不靠感觉，靠顺序", 38, BLU))
e.append(wmc())
P.append(build(e))

# ---- 9 四个坑 ----
e = [head(9)]
e.append(T(MX, 190, "第 8 话 · 四个坑", F_CHAP, "#6B6257"))
keng = [("门禁太慢", "PR 等十分钟 → 开发直接关掉", RED),
        ("阈值拍脑袋", "凭啥 0.8？先用历史分布定", PUR),
        ("只看通过率", "4/4 通过 ≠ 没问题", BLU),
        ("告警没归属", "发群里没人认领 = 噪音", GRN)]
for i, (a, b, col) in enumerate(keng):
    y = 250 + i * 250
    e.append(card(y, 210, WHT))
    e.append(f'<circle cx="{MX+72}" cy="{y+105}" r="40" fill="{col}" stroke="{INK}" stroke-width="6"/>')
    e.append(T(MX + 72, y + 122, "✕", 48, WHT, anchor="middle"))
    e.append(T(MX + 150, y + 92, a, 44))
    e.append(T(MX + 150, y + 164, b, 32, "#6B6257"))
e.append(mascot(230, 1430, 0.6, "sweat"))
e.append(bubble(440, 1300, 580, 190, ["规则写清谁负责", "否则告警就是噪音"], 36, "bl"))
e.append(card(1560, 250, "#EAF3FF"))
e.append(T(MX + 44, 1660, "门禁要有人认领", 38, BLU))
e.append(T(MX + 44, 1740, "不然第二天自己就绿了", 32, "#6B6257"))
e.append(wmc())
P.append(build(e))

# ---- 10 收尾 + CTA ----
e = [head(10)]
e.append(T(MX, 190, "第 9 话 · 写在最后", F_CHAP, "#6B6257"))
e.append(T(W // 2, 350, "三句话", 88, RED, anchor="middle"))
e.append(card(430, 440, WHT))
e.append(T(MX + 44, 540, "① 提交时", 44, BLU))
e.append(T(MX + 260, 540, "便宜的先拦（秒级）", 34))
e.append(T(MX + 44, 650, "② 夜里", 44, GRN))
e.append(T(MX + 260, 650, "贵的全跑 + 门禁判定", 34))
e.append(T(MX + 44, 760, "③ 出事后", 44, RED))
e.append(T(MX + 260, 760, "取证 → 固化成用例", 34))
e.append(card(920, 230, "#FFF3C4"))
e.append(T(MX + 44, 1040, "做到第三条", 40))
e.append(T(MX + 44, 1120, "你就不再是每次救火的人", 40, RED))
e.append(mascot(240, 1420, 0.66, "yeah"))
e.append(bubble(450, 1300, 570, 200, ["而是让火", "越来越难烧起来的人"], 38, "bl"))
e.append(card(1600, 160, "#EAF3FF"))
e.append(T(MX + 44, 1706, "门禁脚本 + CI 模板免费领", 38, BLU))
e.append(wmc())
P.append(build(e))

for i, svg in enumerate(P, 1):
    save(f"sticker-s2q-{i:02d}", svg)

# ============================================================ 横版封面
CW2, CH2 = 1880, 800
e = [f'<rect width="{CW2}" height="{CH2}" fill="{PAPER}"/>',
     f'<rect width="{CW2}" height="{CH2}" fill="url(#dots)"/>']
e.append(f'<rect x="0" y="0" width="{CW2}" height="16" fill="{GRN}"/>')
e.append(badge(90, 60, "漫说测试 · 实战篇 04", YEL, 40))
e.append(T(90, 310, "质量流水线", 100, INK))
e.append(T(90, 430, "评测 · 追踪 · 监控怎么串起来", 66, BLU, sw=3))
e.append(T(90, 520, "出问题先看哪个？有固定顺序，不靠感觉", 40, "#6B6257"))
e.append(mascot(1530, 370, 1.0, "yeah"))
e.append(bubble(1150, 570, 640, 170, ["顺序对了就不乱"], 44, "none"))
e.append(T(90, 660, "公众号：Python测试之道    ·    源码领取：后台回复「agent」", 38, INK))
e.append(sfx(1020, 235, "叮", 64, -12, RED))
save("cover-s2q-01", build(e, CW2, CH2), CW2, CH2)
print("all done")
