#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第二季实战篇 02 图形：
   - 10 张竖版贴图（1080x1920，sticker-s2h2-01..10）
   - 3 张文章配图（1600x1000，fig-s2h2-a/b/c）
   - 1 张横版封面（1880x800，cover-s2h2-01）
主题：评测红了，到底是评测错了还是产品错了（假阴性 vs 真缺陷）
"""
import os, subprocess

OUT = os.path.expanduser("~/.openclaw/workspace/session-files/01M20S67DZSWEWWHNP370TWZVB/agent-testing-series/figs")
os.makedirs(OUT, exist_ok=True)

W, H = 1080, 1920
MX = 80
CW = W - MX * 2
BG = "#0e1730"
PANEL = "#16264a"
EDGE = "#2a4170"
ACCENT = "#ffb454"
BLUE = "#5b8def"
TXT = "#e8eefb"
SUB = "#9fb3d8"
DIM = "#6f87b5"
GREEN = "#4ec98a"
RED = "#ff7a7a"
PURPLE = "#b07aff"


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def T(x, y, s, size, fill, bold=False, anchor="start"):
    fw = ' font-weight="bold"' if bold else ''
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}"{fw} text-anchor="{anchor}">{esc(s)}</text>'


def header(n, total=10):
    return (T(MX, 64, "Agent 测试进阶实战（第二季）· 实战篇 02", 23, DIM)
            + f'<rect x="{W-MX-84}" y="34" width="84" height="44" rx="22" fill="{PANEL}" stroke="{EDGE}" stroke-width="2"/>'
            + T(W-MX-42, 64, f"{n}/{total}", 25, TXT, True, "middle"))


def wm():
    return (f'<rect x="{(W-320)//2}" y="1852" width="320" height="44" rx="22" fill="#1b2d55"/>'
            + T(W//2, 1882, "Python测试之道", 24, "#8fa6d6", True, "middle")
            + f'<g transform="rotate(-24 330 1500)" opacity="0.07">' + T(120, 1500, "Python测试之道", 118, "#ffffff", True) + '</g>'
            + f'<g transform="rotate(-24 720 1690)" opacity="0.05">' + T(520, 1710, "Python测试之道", 118, "#ffffff", True) + '</g>')


def title_block(y, lines, sub=None, size=62):
    s, cur = "", y
    for ln in lines:
        s += T(W//2, cur, ln, size, "#ffffff", True, "middle")
        cur += int(size * 1.3)
    if sub:
        cur += 4
        s += T(W//2, cur, sub, 31, SUB, anchor="middle")
        cur += 46
    s += f'<rect x="{(W-120)//2}" y="{cur}" width="120" height="6" rx="3" fill="{BLUE}"/>'
    return s, cur + 52


def note(y, label, lines, lh=50, size=32, edge="#3b6fd4", lcol=ACCENT):
    h = 82 + lh * len(lines)
    s = f'<rect x="{MX}" y="{y}" width="{CW}" height="{h}" rx="18" fill="#1d2f58" stroke="{edge}" stroke-width="2.5"/>'
    s += T(MX + 30, y + 44, label, 24, lcol, True)
    cy = y + 86
    for ln in lines:
        s += T(MX + 30, cy, ln, size, TXT)
        cy += lh
    return s, y + h + 40


def rows(y, items, size=29, lh=42, pad=30):
    s = ""
    for head, lines in items:
        head_y = y + pad + 32
        line1 = head_y + 46
        h = (line1 - y) + lh * (len(lines) - 1) + 40
        s += f'<rect x="{MX}" y="{y}" width="{CW}" height="{h}" rx="18" fill="{PANEL}" stroke="{EDGE}" stroke-width="2"/>'
        s += f'<circle cx="{MX+34}" cy="{head_y-10}" r="7" fill="{ACCENT}"/>'
        s += T(MX + 60, head_y, head, size + 1, TXT, True)
        cy = line1
        for ln in lines:
            s += T(MX + 60, cy, ln, 26, SUB)
            cy += lh
        y += h + 22
    return s, y


def code(y, lines, size=25, lh=40, label="现场", colors=None):
    h = 76 + lh * len(lines)
    s = f'<rect x="{MX}" y="{y}" width="{CW}" height="{h}" rx="16" fill="#0a1124" stroke="#243a63" stroke-width="2"/>'
    s += T(MX + 26, y + 44, label, 22, DIM, True)
    cy = y + 80
    for i, ln in enumerate(lines):
        col = "#a7e0b8"
        if colors and i < len(colors) and colors[i]:
            col = colors[i]
        s += T(MX + 26, cy, ln, size, col)
        cy += lh
    return s, y + h + 40


def build(elems, w=W, h=H, bg=BG):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'font-family="Noto Sans CJK SC, sans-serif">'
            f'<rect width="{w}" height="{h}" fill="{bg}"/>' + "".join(elems) + "</svg>")


def save(name, svg, w=W, h=H):
    ps = os.path.join(OUT, f"{name}-src.svg")
    pp = os.path.join(OUT, f"{name}.png")
    open(ps, "w", encoding="utf-8").write(svg)
    subprocess.run(["convert", "-background", "none", ps, pp], check=True)
    print("saved", pp)


# ============================================================ 10 张竖版贴图
pages = []

# ---- P1 封面 ----
e = [header(1)]
e.append('<rect x="230" y="196" width="620" height="54" rx="27" fill="#3b6fd4"/>')
e.append(T(W // 2, 231, "第二季 · 实战篇 02 贴图速读", 27, "#ffffff", True, "middle"))
t, y = title_block(350, ["评测红了", "到底谁错了？"], "假阴性 vs 真缺陷 · 一次真实排查", size=68)
e.append(t)
y += 20
for i, kw in enumerate(["看证据", "看复现", "看维度"]):
    x0 = 70 + i * 325
    e.append(f'<rect x="{x0}" y="{y}" width="300" height="60" rx="30" fill="#22375f" stroke="#3b6fd4" stroke-width="2"/>')
    e.append(T(x0 + 150, y + 39, kw, 28, "#cfe0ff", True, "middle"))
y += 132
e.append(T(W // 2, y, "别信“谁”，信证据。", 32, ACCENT, True, anchor="middle"))
e.append('<rect x="250" y="1590" width="580" height="130" rx="18" fill="#1b2d55" stroke="#4ec98a" stroke-width="2"/>')
e.append(T(540, 1642, "实测：2/3 失败 → 0/3", 34, GREEN, True, "middle"))
e.append(T(540, 1692, "定位到“模型抖动”，不是假阴性", 26, SUB, anchor="middle"))
e.append(T(540, 1776, "Python测试之道 · 第二季实战篇 02", 23, DIM, anchor="middle"))
e.append(wm())
pages.append(build(e))

# ---- P2 三种红 ----
e = [header(2)]
e.append(T(MX, 150, "先分诊 · 红不是一种红", 30, SUB))
t, y = title_block(210, ["三种「红」，", "处置完全相反"], size=62)
e.append(t)
s, y = rows(y, [
    ("① 逻辑缺陷", ["产品真错了：稳定复现，证据指向代码逻辑", "处置：提 bug，修产品"]),
    ("② 假阴性", ["评测自己错了：产品行为其实正确", "处置：修评测，别动产品"]),
    ("③ 抖动型不稳定", ["概率性时好时坏：同输入结果不同", "处置：容错 + 可观测"]),
], 0)
e.append(s)
n, y = note(y, "难点", ["它们长得一模一样，不会自带标签", "所以你需要一套方法去“逼问”它"])
e.append(n)
e.append(wm())
pages.append(build(e))

# ---- P3 假阴性的代价 ----
e = [header(3)]
e.append(T(MX, 150, "为什么必须分清", 30, SUB))
t, y = title_block(210, ["假阴性，", "会骗你盖章"], size=64)
e.append(t)
s, y = rows(y, [
    ("判断「这是缺陷」", ["其实是评测问题", "开发被你骚扰三次后，再也不信你的红色"]),
    ("判断「这是评测问题」", ["其实是真缺陷", "缺陷漏到线上，你背锅"]),
], 0)
e.append(s)
n, y = note(y, "真实案例（同项目）", ["提示词是 .md，加载器只认 .txt → Agent 没吃到提示词", "评测却照样全绿：产品不达标，评测自己瞎了"], edge="#ff7a7a")
e.append(n)
e.append(T(MX, y, "这就是假阴性：评测系统自己骗了自己。", 29, RED, True))
e.append(wm())
pages.append(build(e))

# ---- P4 三角定位法 ----
e = [header(4)]
e.append(T(MX, 150, "方法 · 三角定位", 30, SUB))
t, y = title_block(210, ["三个问题", "逼出真相"], size=64)
e.append(t)
s, y = rows(y, [
    ("① 证据链完整吗", ["看现场，不看错误码", "原始 state / 工具调用 / 结构化输出"]),
    ("② 能稳定复现吗", ["绕开框架，单独调那个模块", "连跑 3 次（跑 1 次不算数）"]),
    ("③ 换维度也错吗", ["规则断言 ↔ LLM 指标，交叉验证", "结论反转 → 先怀疑断言"]),
], 0)
e.append(s)
n, y = note(y, "口诀", ["看证据 → 看复现 → 看维度", "三问还犹豫，说明证据不够，不是结论不够"])
e.append(n)
e.append(wm())
pages.append(build(e))

# ---- P5 案例现象 ----
e = [header(5)]
e.append(T(MX, 150, "案例 · 现象", 30, SUB))
t, y = title_block(210, ["时好时坏", "2/3 失败"], size=66)
e.append(t)
s, y = code(y, [
    "assert '3' in '无法查询 P0 优先级测试用例数量，",
    "  数据库查询子专家返回了无效结果",
    "  （错误代码：INVALID_SUBAGENT_RESULT）。'",
], label="多 Agent（Supervisor）模式下")
e.append(s)
n, y = note(y, "对照", ["单 Agent 模式：同一条用例 5 次全绿", "同一个库、同一条 SQL、同一份种子数据"], edge="#4ec98a")
e.append(n)
e.append(T(MX, y, "第一反应「数据库坏了」—— 一秒被排除。", 29, ACCENT, True))
e.append(wm())
pages.append(build(e))

# ---- P6 最小复现 ----
e = [header(6)]
e.append(T(MX, 150, "缩小范围 · 最小复现", 30, SUB))
t, y = title_block(210, ["绕开框架", "只调那一个模块"], size=62)
e.append(t)
s, y = code(y, [
    "第1次: status=error  INVALID_SUBAGENT_RESULT",
    "第2次: status=error  INVALID_SUBAGENT_RESULT",
    "第3次: status=success",
], label="单独构建 SQL 子 Agent · 连跑 3 次")
e.append(s)
n, y = note(y, "结论", ["不是稳定失败 → 排除纯逻辑缺陷", "不是稳定通过 → 排除假阴性", "它是 ③ 抖动型不稳定"], edge="#b07aff")
e.append(n)
e.append(wm())
pages.append(build(e))

# ---- P7 抓现场（核心证据）----
e = [header(7)]
e.append(T(MX, 150, "最关键一步 · 抓现场", 30, SUB))
t, y = title_block(205, ["去看原始 state", "别只看错误码"], size=60)
e.append(t)
s, y = code(y, [
    "AIMessage | calls=['sql_db_query_checker']",
    "ToolMessage | SELECT COUNT(*) ... WHERE priority='P0'",
    "AIMessage | calls=['sql_db_query']",
    "ToolMessage | [(3,)]              ← 数据是对的！",
    "AIMessage | calls=None            ← 就是它",
], label="失败时的最后几条消息", colors=[None, None, None, "#a7e0b8", "#ff7a7a"])
e.append(s)
n, y = note(y, "真相", ["模型查完了数据（结果就是 3），却忘了调用", "结构化输出工具 SubagentResult 就结束了"], edge="#ff7a7a")
e.append(n)
e.append(T(MX, y, "数据没错 · SQL 没错 · 评测也没错。", 29, ACCENT, True))
e.append(wm())
pages.append(build(e))

# ---- P8 定性 ----
e = [header(8)]
e.append(T(MX, 150, "定性 · 别搞混", 30, SUB))
t, y = title_block(210, ["偶发 ≠ 假阴性", "报错难看 ≠ 评测错了"], size=54)
e.append(t)
s, y = rows(y, [
    ("评测没撒谎", ["子 Agent 确实没返回有效结果", "INVALID_SUBAGENT_RESULT 是如实记录"]),
    ("也不是逻辑错", ["没有哪一行代码写错", "它是概率问题，不是逻辑问题"]),
], 0)
e.append(s)
n, y = note(y, "正确定义", ["抖动型缺陷 = 正确率 < 100%，但不可稳定复现", "最可怕的是：伪装成“偶发失败”被忽略"], edge="#ffb454")
e.append(n)
e.append(T(MX, y, "开发一句“重跑就好”，33% 失败率就被盖过去了。", 27, RED, True))
e.append(wm())
pages.append(build(e))

# ---- P9 处置 ----
e = [header(9)]
e.append(T(MX, 150, "处置 · 重试算掩盖吗", 30, SUB))
t, y = title_block(210, ["裸重试=掩盖", "可观测重试=治理"], size=54)
e.append(t)
s, y = code(y, [
    "for _ in range(2):            # 上限 2 次，不无限重试",
    "    state = agent.invoke(payload)",
    "    if not INVALID: return    # 成功即返回",
    "# 两次都失败 → 如实上报，不吞",
], label="容错：只重试“终态可判”的失败")
e.append(s)
n, y = note(y, "但必须配可观测", ["记录重试率 + 首次成功率", "首次成功率才是真实稳定性；重试只是兜底"], edge="#4ec98a")
e.append(n)
e.append(T(MX, y, "让它失败得看得见，而不是让它不失败。", 28, ACCENT, True))
e.append(wm())
pages.append(build(e))

# ---- P10 判据表 + CTA ----
e = [header(10)]
e.append(T(MX, 150, "一张判据表 · 速查", 30, SUB))
t, y = title_block(205, ["下次照着套"], size=62)
e.append(t)
s, y = rows(y, [
    ("稳定复现 + 指向逻辑", ["→ ① 真缺陷：提 bug"]),
    ("单架构绿、多架构挂", ["→ ③ 抖动：单独复现“交接点”"]),
    ("断言不过但人工看对", ["→ ② 假阴性：查断言/类型/阈值"]),
    ("配置改了像没改", ["→ ② 假阴性：先验证配置生效"]),
], 0)
e.append(s)
e.append('<rect x="230" y="1470" width="620" height="150" rx="18" fill="#1b2d55" stroke="#ffb454" stroke-width="2.5"/>')
e.append(T(540, 1522, "完整源码 + 诊断脚本", 30, "#ffffff", True, "middle"))
e.append(T(540, 1572, "后台回复「agent」· 夸克网盘领取", 26, ACCENT, True, "middle"))
e.append(T(540, 1646, "点赞 · 在看 · 转发", 25, SUB, anchor="middle"))
e.append(wm())
pages.append(build(e))

for i, svg in enumerate(pages, 1):
    save(f"sticker-s2h2-{i:02d}", svg)

# ============================================================ 3 张文章配图
FW, FH = 1600, 1000
FX = 70
FCW = FW - FX * 2

# ---- fig A：分诊决策树 ----
e = [T(FX, 70, "图 A · 三种「红」的分诊决策树", 34, "#ffffff", True)]
e.append(T(FX, 122, "别急着改代码、也别急着改断言——先回答三个问题", 24, SUB))
e.append(f'<rect x="{FX}" y="200" width="{FCW}" height="120" rx="16" fill="{PANEL}" stroke="{BLUE}" stroke-width="3"/>')
e.append(T(FX + 30, 250, "Q1 证据链完整吗？", 30, "#ffffff", True))
e.append(T(FX + 30, 292, "把原始 state 打出来：消息列表 / 工具调用 / 结构化输出 —— 看现场，不看错误码", 23, TXT))
e.append(f'<rect x="{FX}" y="340" width="{FCW}" height="120" rx="16" fill="{PANEL}" stroke="{BLUE}" stroke-width="3"/>')
e.append(T(FX + 30, 390, "Q2 能稳定复现吗？", 30, "#ffffff", True))
e.append(T(FX + 30, 432, "绕开评测框架，单独调那个模块，连跑 3 次（跑 1 次不算数）", 23, TXT))
e.append(f'<rect x="{FX}" y="480" width="{FCW}" height="120" rx="16" fill="{PANEL}" stroke="{BLUE}" stroke-width="3"/>')
e.append(T(FX + 30, 530, "Q3 换个维度也错吗？", 30, "#ffffff", True))
e.append(T(FX + 30, 572, "规则断言 ↔ LLM 指标交叉验证；结论反转 → 先怀疑断言本身", 23, TXT))
cards = [
    ("稳定失败", "① 逻辑缺陷", "提 bug · 附最小复现", RED),
    ("时好时坏", "③ 抖动", "容错 + 可观测", PURPLE),
    ("稳定通过", "② 假阴性", "查断言/类型/配置是否生效", ACCENT),
]
cw = (FCW - 2 * 26) // 3
for i, (cond, name, act, col) in enumerate(cards):
    x = FX + i * (cw + 26)
    e.append(f'<rect x="{x}" y="640" width="{cw}" height="230" rx="18" fill="#1d2f58" stroke="{col}" stroke-width="3"/>')
    e.append(T(x + cw // 2, 692, cond, 24, SUB, anchor="middle"))
    e.append(T(x + cw // 2, 748, name, 34, col, True, "middle"))
    e.append(T(x + cw // 2, 800, act, 22, TXT, anchor="middle"))
    e.append(T(x + cw // 2, 840, "→", 26, DIM, True, "middle"))
e.append(T(FX, 940, "口诀：看证据 → 看复现 → 看维度。三问还犹豫，说明证据不够。", 26, ACCENT, True))
e.append(T(FW - FX, 968, "Python测试之道 · 第二季实战篇 02", 22, DIM, False, "end"))
save("fig-s2h2-a", build(e, FW, FH))

# ---- fig B：现场证据 ----
e = [T(FX, 70, "图 B · 一次排查的现场证据", 34, "#ffffff", True)]
e.append(T(FX, 122, "错误码只是“结论”，原始 state 才是“现场”", 24, SUB))
e.append(f'<rect x="{FX}" y="200" width="{(FCW-30)//2}" height="560" rx="18" fill="#0a1124" stroke="#ff7a7a" stroke-width="3"/>')
e.append(T(FX + 26, 250, "失败时 · structured_response 缺失", 24, RED, True))
for i, (ln, col) in enumerate([
    ("AIMessage    calls=['sql_db_query_checker']", None),
    ("ToolMessage  SELECT COUNT(*) ... priority='P0'", None),
    ("AIMessage    calls=['sql_db_query']", None),
    ("ToolMessage  [(3,)]        ← 数据是对的", GREEN),
    ("", None),
    ("AIMessage    calls=None     ← 就是它", RED),
    ("（模型忘了调用结构化输出工具", RED),
    ("  SubagentResult 就结束了）", RED),
]):
    e.append(T(FX + 26, 300 + i * 44, ln, 20, col or "#a7e0b8"))
x2 = FX + (FCW - 30) // 2 + 30
e.append(f'<rect x="{x2}" y="200" width="{(FCW-30)//2}" height="560" rx="18" fill="#0a1124" stroke="#4ec98a" stroke-width="3"/>')
e.append(T(x2 + 26, 250, "成功时 · 正常收尾", 24, GREEN, True))
for i, (ln, col) in enumerate([
    ("AIMessage    calls=['sql_db_query']", None),
    ("ToolMessage  [(3,)]", None),
    ("", None),
    ("AIMessage    calls=['SubagentResult']  ← 正常", GREEN),
    ("ToolMessage  Returning structured response", GREEN),
    ("             status='success' count=3", GREEN),
]):
    e.append(T(x2 + 26, 300 + i * 44, ln, 20, col or "#a7e0b8"))
e.append(f'<rect x="{FX}" y="790" width="{FCW}" height="150" rx="18" fill="#1d2f58" stroke="#ffb454" stroke-width="2.5"/>')
e.append(T(FX + 30, 840, "判定：不是假阴性，是被测系统的抖动型缺陷", 26, "#ffffff", True))
e.append(T(FX + 30, 884, "证据链真相：数据没错、SQL 没错、评测也没错 —— 是模型“收尾”时偶发漏动作。", 23, TXT))
e.append(T(FX + 30, 916, "处置：给终态可判的失败加一次重试（2/3 → 0/3），并把重试率做成指标。", 23, TXT))
save("fig-s2h2-b", build(e, FW, FH))

# ---- fig C：治理模型 ----
e = [T(FX, 70, "图 C · 抖动治理 = 容错 + 可观测", 34, "#ffffff", True)]
e.append(T(FX, 122, "对待概率问题：不是让它不失败，而是让它失败得看得见", 24, SUB))
e.append(f'<rect x="{FX}" y="200" width="{(FCW-40)//2}" height="330" rx="18" fill="{PANEL}" stroke="#4ec98a" stroke-width="3"/>')
e.append(T(FX + 30, 256, "腿一 · 容错（把概率降下来）", 27, GREEN, True))
for i, ln in enumerate([
    "只重试“终态可判”的失败（如没吐结构化结果）",
    "重试要有上限、要带超时",
    "只重试幂等 / 只读操作（写操作先想副作用）",
    "重试仍失败 → 如实上报，不吞",
]):
    e.append(T(FX + 30, 312 + i * 46, "· " + ln, 22, TXT))
x2 = FX + (FCW - 40) // 2 + 40
e.append(f'<rect x="{x2}" y="200" width="{(FCW-40)//2}" height="330" rx="18" fill="{PANEL}" stroke="#5b8def" stroke-width="3"/>')
e.append(T(x2 + 30, 256, "腿二 · 可观测（把概率暴露）", 27, BLUE, True))
for i, ln in enumerate([
    "记录重试次数 / 重试率",
    "记录首次成功率（真实稳定性）",
    "把重试率做成正式质量指标，进监控与趋势",
    "重试只是兜底，不是成绩",
]):
    e.append(T(x2 + 30, 312 + i * 46, "· " + ln, 22, TXT))
e.append(f'<rect x="{FX}" y="570" width="{FCW}" height="180" rx="18" fill="#0a1124" stroke="#243a63" stroke-width="2"/>')
e.append(T(FX + 28, 618, "留档后你看到的是：", 24, ACCENT, True))
for i, ln in enumerate([
    "用例通过率 100%（但重试率 66% → 真实首次成功率 34%，仍在告警）",
    "→ 指标一片绿，不等于系统稳；看得见的不稳定，才治得了。",
]):
    e.append(T(FX + 28, 662 + i * 40, ln, 22, "#a7e0b8"))
e.append(f'<rect x="{FX}" y="790" width="{FCW}" height="150" rx="18" fill="#1d2f58" stroke="#ffb454" stroke-width="2.5"/>')
e.append(T(FX + 30, 840, "结论一句话", 26, "#ffffff", True))
e.append(T(FX + 30, 884, "评测的专业性，不在于断言写得多漂亮，而在于红色出现时，", 23, TXT))
e.append(T(FX + 30, 916, "你能不能在 10 分钟内告诉团队：这是谁的错。", 23, TXT))
e.append(T(FW - FX, 968, "Python测试之道 · 第二季实战篇 02", 22, DIM, False, "end"))
save("fig-s2h2-c", build(e, FW, FH))

# ============================================================ 横版封面
CW2, CH2 = 1880, 800
e = ['<rect width="1880" height="800" fill="#0b1226"/>']
e.append('<rect x="0" y="0" width="1880" height="8" fill="#ffb454"/>')
e.append(T(90, 150, "Agent 测试进阶实战（第二季）· 实战篇 02", 30, "#8fa6d6"))
e.append(T(90, 300, "评测红了，到底谁错了？", 82, "#ffffff", True))
e.append(T(90, 396, "假阴性 vs 真缺陷：一次真实排查的完整证据链", 36, "#9fb3d8"))
e.append('<rect x="90" y="452" width="150" height="6" rx="3" fill="#3b6fd4"/>')
for i, kw in enumerate(["三角定位法", "抓原始 state", "容错 + 可观测"]):
    x0 = 90 + i * 380
    e.append(f'<rect x="{x0}" y="520" width="350" height="66" rx="33" fill="#16264a" stroke="#2a4170" stroke-width="2"/>')
    e.append(T(x0 + 175, 562, kw, 28, "#cfe0ff", True, "middle"))
e.append('<rect x="1360" y="470" width="440" height="150" rx="20" fill="#16264a" stroke="#4ec98a" stroke-width="2.5"/>')
e.append(T(1580, 528, "2/3 失败", 30, "#ff7a7a", True, "middle"))
e.append(T(1580, 580, "→ 0/3 失败", 30, GREEN, True, "middle"))
e.append(T(90, 700, "公众号：Python测试之道   ·   源码领取：后台回复「agent」", 30, "#ffb454", True))
e.append('<g transform="rotate(-24 1500 300)" opacity="0.06">' + T(1180, 300, "Python测试之道", 130, "#ffffff", True) + '</g>')
e.append('<g transform="rotate(-24 1600 640)" opacity="0.05">' + T(1250, 660, "Python测试之道", 130, "#ffffff", True) + '</g>')
save("cover-s2h2-01", build(e, CW2, CH2, "#0b1226"), CW2, CH2)

print("all done")
